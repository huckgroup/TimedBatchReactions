#include "amici/symbolic_functions.h"
#include "amici/defines.h"
#include "sundials/sundials_types.h"

#include <gsl/gsl-lite.hpp>
#include <algorithm>

#include "p.h"
#include "y.h"
#include "sigmay.h"
#include "my.h"

namespace amici {
namespace model_name_final_ADP_forward {

void Jy_name_final_ADP_forward(realtype *Jy, const int iy, const realtype *p, const realtype *k, const realtype *y, const realtype *sigmay, const realtype *my){
    switch(iy) {
        case 0:
            Jy[0] = 0.5*std::log(2*amici::pi*std::pow(sigma_yy3, 2)) + 0.5*std::pow(-myy3 + yy3, 2)/std::pow(sigma_yy3, 2);
            break;
        case 1:
            Jy[0] = 0.5*std::log(2*amici::pi*std::pow(sigma_yy0, 2)) + 0.5*std::pow(-myy0 + yy0, 2)/std::pow(sigma_yy0, 2);
            break;
        case 2:
            Jy[0] = 0.5*std::log(2*amici::pi*std::pow(sigma_yy11, 2)) + 0.5*std::pow(-myy11 + yy11, 2)/std::pow(sigma_yy11, 2);
            break;
        case 3:
            Jy[0] = 0.5*std::log(2*amici::pi*std::pow(sigma_yy1, 2)) + 0.5*std::pow(-myy1 + yy1, 2)/std::pow(sigma_yy1, 2);
            break;
        case 4:
            Jy[0] = 0.5*std::log(2*amici::pi*std::pow(sigma_yy2, 2)) + 0.5*std::pow(-myy2 + yy2, 2)/std::pow(sigma_yy2, 2);
            break;
        case 5:
            Jy[0] = 0.5*std::log(2*amici::pi*std::pow(sigma_yy6, 2)) + 0.5*std::pow(-myy6 + yy6, 2)/std::pow(sigma_yy6, 2);
            break;
        case 6:
            Jy[0] = 0.5*std::log(2*amici::pi*std::pow(sigma_yy13, 2)) + 0.5*std::pow(-myy13 + yy13, 2)/std::pow(sigma_yy13, 2);
            break;
        case 7:
            Jy[0] = 0.5*std::log(2*amici::pi*std::pow(sigma_yy4, 2)) + 0.5*std::pow(-myy4 + yy4, 2)/std::pow(sigma_yy4, 2);
            break;
        case 8:
            Jy[0] = 0.5*std::log(2*amici::pi*std::pow(sigma_yy5, 2)) + 0.5*std::pow(-myy5 + yy5, 2)/std::pow(sigma_yy5, 2);
            break;
        case 9:
            Jy[0] = 0.5*std::log(2*amici::pi*std::pow(sigma_yy8, 2)) + 0.5*std::pow(-myy8 + yy8, 2)/std::pow(sigma_yy8, 2);
            break;
        case 10:
            Jy[0] = 0.5*std::log(2*amici::pi*std::pow(sigma_yy10, 2)) + 0.5*std::pow(-myy10 + yy10, 2)/std::pow(sigma_yy10, 2);
            break;
        case 11:
            Jy[0] = 0.5*std::log(2*amici::pi*std::pow(sigma_yy12, 2)) + 0.5*std::pow(-myy12 + yy12, 2)/std::pow(sigma_yy12, 2);
            break;
        case 12:
            Jy[0] = 0.5*std::log(2*amici::pi*std::pow(sigma_yy7, 2)) + 0.5*std::pow(-myy7 + yy7, 2)/std::pow(sigma_yy7, 2);
            break;
        case 13:
            Jy[0] = 0.5*std::log(2*amici::pi*std::pow(sigma_yy9, 2)) + 0.5*std::pow(-myy9 + yy9, 2)/std::pow(sigma_yy9, 2);
            break;
        case 14:
            Jy[0] = 0.5*std::log(2*amici::pi*std::pow(sigma_yy15, 2)) + 0.5*std::pow(-myy15 + yy15, 2)/std::pow(sigma_yy15, 2);
            break;
        case 15:
            Jy[0] = 0.5*std::log(2*amici::pi*std::pow(sigma_yy14, 2)) + 0.5*std::pow(-myy14 + yy14, 2)/std::pow(sigma_yy14, 2);
            break;
        case 16:
            Jy[0] = 0.5*std::log(2*amici::pi*std::pow(sigma_ydefault_compartment, 2)) + 0.5*std::pow(-mydefault_compartment + ydefault_compartment, 2)/std::pow(sigma_ydefault_compartment, 2);
            break;
    }
}

} // namespace model_name_final_ADP_forward
} // namespace amici
