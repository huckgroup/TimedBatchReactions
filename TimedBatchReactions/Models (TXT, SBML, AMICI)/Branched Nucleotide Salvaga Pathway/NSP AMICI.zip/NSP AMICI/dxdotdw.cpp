#include "amici/sundials_matrix_wrapper.h"
#include "sundials/sundials_types.h"

#include <array>
#include <algorithm>

namespace amici {
namespace model_name_final_ADP_forward {

static constexpr std::array<sunindextype, 61> dxdotdw_colptrs_name_final_ADP_forward_ = {
    0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60
};

void dxdotdw_colptrs_name_final_ADP_forward(SUNMatrixWrapper &dxdotdw){
    dxdotdw.set_indexptrs(gsl::make_span(dxdotdw_colptrs_name_final_ADP_forward_));
}
} // namespace model_name_final_ADP_forward
} // namespace amici

#include "amici/sundials_matrix_wrapper.h"
#include "sundials/sundials_types.h"

#include <array>
#include <algorithm>

namespace amici {
namespace model_name_final_ADP_forward {

static constexpr std::array<sunindextype, 60> dxdotdw_rowvals_name_final_ADP_forward_ = {
    0, 1, 3, 4, 5, 2, 4, 0, 7, 8, 5, 9, 6, 3, 7, 1, 3, 4, 10, 3, 5, 12, 6, 1, 13, 11, 3, 5, 12, 14, 4, 8, 0, 8, 12, 15, 1, 4, 0, 7, 8, 0, 8, 12, 0, 8, 9, 13, 2, 15, 7, 9, 13, 10, 0, 3, 12, 9, 11, 14
};

void dxdotdw_rowvals_name_final_ADP_forward(SUNMatrixWrapper &dxdotdw){
    dxdotdw.set_indexvals(gsl::make_span(dxdotdw_rowvals_name_final_ADP_forward_));
}
} // namespace model_name_final_ADP_forward
} // namespace amici




#include "amici/symbolic_functions.h"
#include "amici/defines.h"
#include "sundials/sundials_types.h"

#include <gsl/gsl-lite.hpp>
#include <algorithm>

#include "x.h"
#include "p.h"
#include "w.h"
#include "dxdotdw.h"

namespace amici {
namespace model_name_final_ADP_forward {

void dxdotdw_name_final_ADP_forward(realtype *dxdotdw, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w){
    ddy3dt_dflux_J0 = -1;  // dxdotdw[0]
    ddy0dt_dflux_J1 = -1;  // dxdotdw[1]
    ddy1dt_dflux_J2 = -1;  // dxdotdw[2]
    ddy2dt_dflux_J3 = 1;  // dxdotdw[3]
    ddy6dt_dflux_J4 = 1;  // dxdotdw[4]
    ddy11dt_dflux_J5 = 1;  // dxdotdw[5]
    ddy2dt_dflux_J6 = -1;  // dxdotdw[6]
    ddy3dt_dflux_J7 = -1;  // dxdotdw[7]
    ddy4dt_dflux_J8 = 1;  // dxdotdw[8]
    ddy5dt_dflux_J9 = 1;  // dxdotdw[9]
    ddy6dt_dflux_J10 = -1;  // dxdotdw[10]
    ddy8dt_dflux_J11 = 1;  // dxdotdw[11]
    ddy13dt_dflux_J12 = 1;  // dxdotdw[12]
    ddy1dt_dflux_J13 = -1;  // dxdotdw[13]
    ddy4dt_dflux_J14 = -1;  // dxdotdw[14]
    ddy0dt_dflux_J15 = 1;  // dxdotdw[15]
    ddy1dt_dflux_J16 = 1;  // dxdotdw[16]
    ddy2dt_dflux_J17 = -1;  // dxdotdw[17]
    ddy10dt_dflux_J18 = -1;  // dxdotdw[18]
    ddy1dt_dflux_J19 = -1;  // dxdotdw[19]
    ddy6dt_dflux_J20 = -1;  // dxdotdw[20]
    ddy7dt_dflux_J21 = 1;  // dxdotdw[21]
    ddy13dt_dflux_J22 = -1;  // dxdotdw[22]
    ddy0dt_dflux_J23 = 1;  // dxdotdw[23]
    ddy9dt_dflux_J24 = -1;  // dxdotdw[24]
    ddy12dt_dflux_J25 = 1;  // dxdotdw[25]
    ddy1dt_dflux_J26 = 1;  // dxdotdw[26]
    ddy6dt_dflux_J27 = 1;  // dxdotdw[27]
    ddy7dt_dflux_J28 = -1;  // dxdotdw[28]
    ddy15dt_dflux_J29 = 1;  // dxdotdw[29]
    ddy2dt_dflux_J30 = -1;  // dxdotdw[30]
    ddy5dt_dflux_J31 = -1;  // dxdotdw[31]
    ddy3dt_dflux_J32 = 1;  // dxdotdw[32]
    ddy5dt_dflux_J33 = -1;  // dxdotdw[33]
    ddy7dt_dflux_J34 = 1;  // dxdotdw[34]
    ddy14dt_dflux_J35 = -1;  // dxdotdw[35]
    ddy0dt_dflux_J36 = -1;  // dxdotdw[36]
    ddy2dt_dflux_J37 = 1;  // dxdotdw[37]
    ddy3dt_dflux_J38 = 1;  // dxdotdw[38]
    ddy4dt_dflux_J39 = -1;  // dxdotdw[39]
    ddy5dt_dflux_J40 = -1;  // dxdotdw[40]
    ddy3dt_dflux_J41 = -1;  // dxdotdw[41]
    ddy5dt_dflux_J42 = 1;  // dxdotdw[42]
    ddy7dt_dflux_J43 = -1;  // dxdotdw[43]
    ddy3dt_dflux_J44 = 1;  // dxdotdw[44]
    ddy5dt_dflux_J45 = -1;  // dxdotdw[45]
    ddy8dt_dflux_J46 = -1;  // dxdotdw[46]
    ddy9dt_dflux_J47 = 1;  // dxdotdw[47]
    ddy11dt_dflux_J48 = -1;  // dxdotdw[48]
    ddy14dt_dflux_J49 = 1;  // dxdotdw[49]
    ddy4dt_dflux_J50 = -1;  // dxdotdw[50]
    ddy8dt_dflux_J51 = -1;  // dxdotdw[51]
    ddy9dt_dflux_J52 = 1;  // dxdotdw[52]
    ddy10dt_dflux_J53 = 1;  // dxdotdw[53]
    ddy3dt_dflux_J54 = 1;  // dxdotdw[54]
    ddy1dt_dflux_J55 = 1;  // dxdotdw[55]
    ddy7dt_dflux_J56 = -1;  // dxdotdw[56]
    ddy8dt_dflux_J57 = -1;  // dxdotdw[57]
    ddy12dt_dflux_J58 = -1;  // dxdotdw[58]
    ddy15dt_dflux_J59 = -1;  // dxdotdw[59]
}

} // namespace model_name_final_ADP_forward
} // namespace amici
