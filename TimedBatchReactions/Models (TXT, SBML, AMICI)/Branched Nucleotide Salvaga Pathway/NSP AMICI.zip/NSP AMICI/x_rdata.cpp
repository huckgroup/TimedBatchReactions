#include "amici/symbolic_functions.h"
#include "amici/defines.h"
#include "sundials/sundials_types.h"

#include <gsl/gsl-lite.hpp>
#include <algorithm>

#include "x.h"
#include "p.h"

namespace amici {
namespace model_name_final_ADP_forward {

void x_rdata_name_final_ADP_forward(realtype *x_rdata, const realtype *x, const realtype *tcl, const realtype *p, const realtype *k){
    x_rdata[0] = y3;
    x_rdata[1] = y0;
    x_rdata[2] = y11;
    x_rdata[3] = y1;
    x_rdata[4] = y2;
    x_rdata[5] = y6;
    x_rdata[6] = y13;
    x_rdata[7] = y4;
    x_rdata[8] = y5;
    x_rdata[9] = y8;
    x_rdata[10] = y10;
    x_rdata[11] = y12;
    x_rdata[12] = y7;
    x_rdata[13] = y9;
    x_rdata[14] = y15;
    x_rdata[15] = y14;
}

} // namespace model_name_final_ADP_forward
} // namespace amici
