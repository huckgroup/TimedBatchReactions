#include "amici/symbolic_functions.h"
#include "amici/defines.h"
#include "sundials/sundials_types.h"

#include <gsl/gsl-lite.hpp>
#include <algorithm>

#include "x.h"
#include "p.h"
#include "w.h"
#include "xdot.h"

namespace amici {
namespace model_name_final_ADP_forward {

void xdot_name_final_ADP_forward(realtype *xdot, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w){
    dy3dt = -flux_J0 + flux_J32 + flux_J38 - flux_J41 + flux_J44 + flux_J54 - flux_J7;  // xdot[0]
    dy0dt = -flux_J1 + flux_J15 + flux_J23 - flux_J36;  // xdot[1]
    dy11dt = -flux_J48 + flux_J5;  // xdot[2]
    dy1dt = -flux_J13 + flux_J16 - flux_J19 - flux_J2 + flux_J26 + flux_J55;  // xdot[3]
    dy2dt = -flux_J17 + flux_J3 - flux_J30 + flux_J37 - flux_J6;  // xdot[4]
    dy6dt = -flux_J10 - flux_J20 + flux_J27 + flux_J4;  // xdot[5]
    dy13dt = flux_J12 - flux_J22;  // xdot[6]
    dy4dt = -flux_J14 - flux_J39 - flux_J50 + flux_J8;  // xdot[7]
    dy5dt = -flux_J31 - flux_J33 - flux_J40 + flux_J42 - flux_J45 + flux_J9;  // xdot[8]
    dy8dt = flux_J11 - flux_J46 - flux_J51 - flux_J57;  // xdot[9]
    dy10dt = -flux_J18 + flux_J53;  // xdot[10]
    dy12dt = flux_J25 - flux_J58;  // xdot[11]
    dy7dt = flux_J21 - flux_J28 + flux_J34 - flux_J43 - flux_J56;  // xdot[12]
    dy9dt = -flux_J24 + flux_J47 + flux_J52;  // xdot[13]
    dy15dt = flux_J29 - flux_J59;  // xdot[14]
    dy14dt = -flux_J35 + flux_J49;  // xdot[15]
}

} // namespace model_name_final_ADP_forward
} // namespace amici
