#include "amici/symbolic_functions.h"
#include "amici/defines.h"
#include "sundials/sundials_types.h"

#include <gsl/gsl-lite.hpp>
#include <algorithm>

#include "x.h"
#include "p.h"
#include "w.h"

namespace amici {
namespace model_name_final_ADP_forward {

void w_name_final_ADP_forward(realtype *w, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *tcl, const realtype *spl, bool include_static){
    // static expressions
    if (include_static) {
        flux_J4 = k3*k42/k46;  // w[4]
        flux_J5 = k43*k8/k46;  // w[5]
        flux_J11 = k39*k4/k46;  // w[11]
        flux_J12 = k44*k7/k46;  // w[12]
        flux_J23 = k41*k9/k46;  // w[23]
        flux_J25 = k1*k43/k46;  // w[25]
        flux_J29 = k0*k45/k46;  // w[29]
        flux_J49 = k45*k5/k46;  // w[49]
        flux_J54 = k2*k40/k46;  // w[54]
        flux_J55 = k38*k6/k46;  // w[55]
    }

    // dynamic expressions
    flux_J0 = y3*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // w[0]
    flux_J1 = k19*y0*y1*y11/(k35*k37 + k35*y0 + k37*y1 + y0*y1);  // w[1]
    flux_J2 = k19*y0*y1*y11/(k35*k37 + k35*y0 + k37*y1 + y0*y1);  // w[2]
    flux_J3 = k19*y0*y1*y11/(k35*k37 + k35*y0 + k37*y1 + y0*y1);  // w[3]
    flux_J6 = k18*y13*y2*y3/(k32*k34 + k32*y2 + k34*y3 + y2*y3);  // w[6]
    flux_J7 = k18*y13*y2*y3/(k32*k34 + k32*y2 + k34*y3 + y2*y3);  // w[7]
    flux_J8 = k18*y13*y2*y3/(k32*k34 + k32*y2 + k34*y3 + y2*y3);  // w[8]
    flux_J9 = k18*y13*y2*y3/(k32*k34 + k32*y2 + k34*y3 + y2*y3);  // w[9]
    flux_J10 = y6*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // w[10]
    flux_J13 = y1*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // w[13]
    flux_J14 = y4*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // w[14]
    flux_J15 = k36*y11*y2/(k36 + y2);  // w[15]
    flux_J16 = k36*y11*y2/(k36 + y2);  // w[16]
    flux_J17 = k36*y11*y2/(k36 + y2);  // w[17]
    flux_J18 = y10*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // w[18]
    flux_J19 = k14*y1*y12*y6/(k26*k27 + k26*y1 + k27*y6 + y1*y6);  // w[19]
    flux_J20 = k14*y1*y12*y6/(k26*k27 + k26*y1 + k27*y6 + y1*y6);  // w[20]
    flux_J21 = k14*y1*y12*y6/(k26*k27 + k26*y1 + k27*y6 + y1*y6);  // w[21]
    flux_J22 = y13*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // w[22]
    flux_J24 = y9*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // w[24]
    flux_J26 = k25*y12*y7/(k25 + y7);  // w[26]
    flux_J27 = k25*y12*y7/(k25 + y7);  // w[27]
    flux_J28 = k25*y12*y7/(k25 + y7);  // w[28]
    flux_J30 = y2*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // w[30]
    flux_J31 = y5*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // w[31]
    flux_J32 = k11*y15*std::pow(y5, 2)/(std::pow(k22, 2) + 2*k22*y5 + std::pow(y5, 2));  // w[32]
    flux_J33 = k11*y15*std::pow(y5, 2)/(std::pow(k22, 2) + 2*k22*y5 + std::pow(y5, 2));  // w[33]
    flux_J34 = k11*y15*std::pow(y5, 2)/(std::pow(k22, 2) + 2*k22*y5 + std::pow(y5, 2));  // w[34]
    flux_J35 = y14*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // w[35]
    flux_J36 = y0*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // w[36]
    flux_J37 = k17*y13*y4*y5/(k31*k33 + k31*y4 + k33*y5 + y4*y5);  // w[37]
    flux_J38 = k17*y13*y4*y5/(k31*k33 + k31*y4 + k33*y5 + y4*y5);  // w[38]
    flux_J39 = k17*y13*y4*y5/(k31*k33 + k31*y4 + k33*y5 + y4*y5);  // w[39]
    flux_J40 = k17*y13*y4*y5/(k31*k33 + k31*y4 + k33*y5 + y4*y5);  // w[40]
    flux_J41 = k12*y15*y3*y7/(k23*k24 + k23*y3 + k24*y7 + y3*y7);  // w[41]
    flux_J42 = k12*y15*y3*y7/(k23*k24 + k23*y3 + k24*y7 + y3*y7);  // w[42]
    flux_J43 = k12*y15*y3*y7/(k23*k24 + k23*y3 + k24*y7 + y3*y7);  // w[43]
    flux_J44 = k15*y14*y5*y8*std::pow(1 + y5/k21, -k10)/(k28*k29 + k28*y8 + k29*y5 + y5*y8);  // w[44]
    flux_J45 = k15*y14*y5*y8*std::pow(1 + y5/k21, -k10)/(k28*k29 + k28*y8 + k29*y5 + y5*y8);  // w[45]
    flux_J46 = k15*y14*y5*y8*std::pow(1 + y5/k21, -k10)/(k28*k29 + k28*y8 + k29*y5 + y5*y8);  // w[46]
    flux_J47 = k15*y14*y5*y8*std::pow(1 + y5/k21, -k10)/(k28*k29 + k28*y8 + k29*y5 + y5*y8);  // w[47]
    flux_J48 = y11*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // w[48]
    flux_J50 = k16*y14*y4*y8*std::pow(1 + y5/k21, -k10)/(k29*k30 + k29*y4 + k30*y8 + y4*y8);  // w[50]
    flux_J51 = k16*y14*y4*y8*std::pow(1 + y5/k21, -k10)/(k29*k30 + k29*y4 + k30*y8 + y4*y8);  // w[51]
    flux_J52 = k16*y14*y4*y8*std::pow(1 + y5/k21, -k10)/(k29*k30 + k29*y4 + k30*y8 + y4*y8);  // w[52]
    flux_J53 = k16*y14*y4*y8*std::pow(1 + y5/k21, -k10)/(k29*k30 + k29*y4 + k30*y8 + y4*y8);  // w[53]
    flux_J56 = y7*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // w[56]
    flux_J57 = y8*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // w[57]
    flux_J58 = y12*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // w[58]
    flux_J59 = y15*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // w[59]
}

} // namespace model_name_final_ADP_forward
} // namespace amici
