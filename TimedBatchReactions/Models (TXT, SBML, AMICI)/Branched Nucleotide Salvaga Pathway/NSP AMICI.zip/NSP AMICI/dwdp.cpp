#include "amici/sundials_matrix_wrapper.h"
#include "sundials/sundials_types.h"

#include <array>
#include <algorithm>

namespace amici {
namespace model_name_final_ADP_forward {

static constexpr std::array<sunindextype, 48> dwdp_colptrs_name_final_ADP_forward_ = {
    0, 17, 34, 51, 68, 85, 103, 120, 138, 164, 167, 170, 173, 174, 175, 179, 183, 187, 188, 189, 192, 195, 198, 201, 202, 203, 206, 207, 210, 213, 217, 221, 225, 228, 231, 234, 238, 242, 250, 258, 266, 267, 271, 275, 276, 277, 277, 277
};

void dwdp_colptrs_name_final_ADP_forward(SUNMatrixWrapper &dwdp){
    dwdp.set_indexptrs(gsl::make_span(dwdp_colptrs_name_final_ADP_forward_));
}
} // namespace model_name_final_ADP_forward
} // namespace amici

#include "amici/sundials_matrix_wrapper.h"
#include "sundials/sundials_types.h"

#include <array>
#include <algorithm>

namespace amici {
namespace model_name_final_ADP_forward {

static constexpr std::array<sunindextype, 277> dwdp_rowvals_name_final_ADP_forward_ = {
    0, 10, 13, 14, 18, 22, 24, 30, 31, 35, 36, 48, 55, 56, 57, 58, 59, 0, 10, 11, 13, 14, 18, 22, 24, 30, 31, 35, 36, 48, 56, 57, 58, 59, 0, 10, 13, 14, 18, 22, 24, 30, 31, 35, 36, 48, 54, 56, 57, 58, 59, 0, 10, 13, 14, 18, 22, 23, 24, 30, 31, 35, 36, 48, 56, 57, 58, 59, 0, 4, 10, 13, 14, 18, 22, 24, 30, 31, 35, 36, 48, 56, 57, 58, 59, 0, 5, 10, 13, 14, 18, 22, 24, 25, 30, 31, 35, 36, 48, 56, 57, 58, 59, 0, 10, 12, 13, 14, 18, 22, 24, 30, 31, 35, 36, 48, 56, 57, 58, 59, 0, 10, 13, 14, 18, 22, 24, 29, 30, 31, 35, 36, 48, 49, 56, 57, 58, 59, 0, 4, 5, 10, 11, 12, 13, 14, 18, 22, 23, 24, 25, 29, 30, 31, 35, 36, 48, 49, 54, 55, 56, 57, 58, 59, 1, 2, 3, 1, 2, 3, 1, 2, 3, 4, 5, 6, 7, 8, 9, 6, 7, 8, 9, 6, 7, 8, 9, 11, 12, 15, 16, 17, 19, 20, 21, 19, 20, 21, 19, 20, 21, 23, 25, 26, 27, 28, 29, 32, 33, 34, 32, 33, 34, 37, 38, 39, 40, 37, 38, 39, 40, 37, 38, 39, 40, 41, 42, 43, 41, 42, 43, 41, 42, 43, 44, 45, 46, 47, 44, 45, 46, 47, 44, 45, 46, 47, 50, 51, 52, 53, 44, 45, 46, 47, 50, 51, 52, 53, 44, 45, 46, 47, 50, 51, 52, 53, 49, 50, 51, 52, 53, 50, 51, 52, 53, 54, 55
};

void dwdp_rowvals_name_final_ADP_forward(SUNMatrixWrapper &dwdp){
    dwdp.set_indexvals(gsl::make_span(dwdp_rowvals_name_final_ADP_forward_));
}
} // namespace model_name_final_ADP_forward
} // namespace amici




#include "amici/symbolic_functions.h"
#include "amici/defines.h"
#include "sundials/sundials_types.h"

#include <gsl/gsl-lite.hpp>
#include <algorithm>

#include "x.h"
#include "p.h"
#include "w.h"
#include "dwdp.h"

namespace amici {
namespace model_name_final_ADP_forward {

void dwdp_name_final_ADP_forward(realtype *dwdp, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w, const realtype *tcl, const realtype *dtcldp, const realtype *spl, const realtype *sspl, bool include_static){
    // static expressions
    if (include_static) {
        dflux_J55_dk38 = k6/k46;  // dwdp[12]
        dflux_J11_dk39 = k4/k46;  // dwdp[19]
        dflux_J54_dk40 = k2/k46;  // dwdp[46]
        dflux_J23_dk41 = k9/k46;  // dwdp[57]
        dflux_J4_dk42 = k3/k46;  // dwdp[69]
        dflux_J5_dk43 = k8/k46;  // dwdp[86]
        dflux_J25_dk43 = k1/k46;  // dwdp[93]
        dflux_J12_dk44 = k7/k46;  // dwdp[105]
        dflux_J29_dk45 = k0/k46;  // dwdp[127]
        dflux_J49_dk45 = k5/k46;  // dwdp[133]
        dflux_J4_dk46 = -k3*k42/std::pow(k46, 2);  // dwdp[139]
        dflux_J5_dk46 = -k43*k8/std::pow(k46, 2);  // dwdp[140]
        dflux_J11_dk46 = -k39*k4/std::pow(k46, 2);  // dwdp[142]
        dflux_J12_dk46 = -k44*k7/std::pow(k46, 2);  // dwdp[143]
        dflux_J23_dk46 = -k41*k9/std::pow(k46, 2);  // dwdp[148]
        dflux_J25_dk46 = -k1*k43/std::pow(k46, 2);  // dwdp[150]
        dflux_J29_dk46 = -k0*k45/std::pow(k46, 2);  // dwdp[151]
        dflux_J49_dk46 = -k45*k5/std::pow(k46, 2);  // dwdp[157]
        dflux_J54_dk46 = -k2*k40/std::pow(k46, 2);  // dwdp[158]
        dflux_J55_dk46 = -k38*k6/std::pow(k46, 2);  // dwdp[159]
        dflux_J4_dk3 = k42/k46;  // dwdp[173]
        dflux_J5_dk8 = k43/k46;  // dwdp[174]
        dflux_J11_dk4 = k39/k46;  // dwdp[187]
        dflux_J12_dk7 = k44/k46;  // dwdp[188]
        dflux_J23_dk9 = k41/k46;  // dwdp[201]
        dflux_J25_dk1 = k43/k46;  // dwdp[202]
        dflux_J29_dk0 = k45/k46;  // dwdp[206]
        dflux_J49_dk5 = k45/k46;  // dwdp[266]
        dflux_J54_dk2 = k40/k46;  // dwdp[275]
        dflux_J55_dk6 = k38/k46;  // dwdp[276]
    }

    // dynamic expressions
    dflux_J0_dk38 = y3/k46;  // dwdp[0]
    dflux_J10_dk38 = y6/k46;  // dwdp[1]
    dflux_J13_dk38 = y1/k46;  // dwdp[2]
    dflux_J14_dk38 = y4/k46;  // dwdp[3]
    dflux_J18_dk38 = y10/k46;  // dwdp[4]
    dflux_J22_dk38 = y13/k46;  // dwdp[5]
    dflux_J24_dk38 = y9/k46;  // dwdp[6]
    dflux_J30_dk38 = y2/k46;  // dwdp[7]
    dflux_J31_dk38 = y5/k46;  // dwdp[8]
    dflux_J35_dk38 = y14/k46;  // dwdp[9]
    dflux_J36_dk38 = y0/k46;  // dwdp[10]
    dflux_J48_dk38 = y11/k46;  // dwdp[11]
    dflux_J56_dk38 = y7/k46;  // dwdp[13]
    dflux_J57_dk38 = y8/k46;  // dwdp[14]
    dflux_J58_dk38 = y12/k46;  // dwdp[15]
    dflux_J59_dk38 = y15/k46;  // dwdp[16]
    dflux_J0_dk39 = y3/k46;  // dwdp[17]
    dflux_J10_dk39 = y6/k46;  // dwdp[18]
    dflux_J13_dk39 = y1/k46;  // dwdp[20]
    dflux_J14_dk39 = y4/k46;  // dwdp[21]
    dflux_J18_dk39 = y10/k46;  // dwdp[22]
    dflux_J22_dk39 = y13/k46;  // dwdp[23]
    dflux_J24_dk39 = y9/k46;  // dwdp[24]
    dflux_J30_dk39 = y2/k46;  // dwdp[25]
    dflux_J31_dk39 = y5/k46;  // dwdp[26]
    dflux_J35_dk39 = y14/k46;  // dwdp[27]
    dflux_J36_dk39 = y0/k46;  // dwdp[28]
    dflux_J48_dk39 = y11/k46;  // dwdp[29]
    dflux_J56_dk39 = y7/k46;  // dwdp[30]
    dflux_J57_dk39 = y8/k46;  // dwdp[31]
    dflux_J58_dk39 = y12/k46;  // dwdp[32]
    dflux_J59_dk39 = y15/k46;  // dwdp[33]
    dflux_J0_dk40 = y3/k46;  // dwdp[34]
    dflux_J10_dk40 = y6/k46;  // dwdp[35]
    dflux_J13_dk40 = y1/k46;  // dwdp[36]
    dflux_J14_dk40 = y4/k46;  // dwdp[37]
    dflux_J18_dk40 = y10/k46;  // dwdp[38]
    dflux_J22_dk40 = y13/k46;  // dwdp[39]
    dflux_J24_dk40 = y9/k46;  // dwdp[40]
    dflux_J30_dk40 = y2/k46;  // dwdp[41]
    dflux_J31_dk40 = y5/k46;  // dwdp[42]
    dflux_J35_dk40 = y14/k46;  // dwdp[43]
    dflux_J36_dk40 = y0/k46;  // dwdp[44]
    dflux_J48_dk40 = y11/k46;  // dwdp[45]
    dflux_J56_dk40 = y7/k46;  // dwdp[47]
    dflux_J57_dk40 = y8/k46;  // dwdp[48]
    dflux_J58_dk40 = y12/k46;  // dwdp[49]
    dflux_J59_dk40 = y15/k46;  // dwdp[50]
    dflux_J0_dk41 = y3/k46;  // dwdp[51]
    dflux_J10_dk41 = y6/k46;  // dwdp[52]
    dflux_J13_dk41 = y1/k46;  // dwdp[53]
    dflux_J14_dk41 = y4/k46;  // dwdp[54]
    dflux_J18_dk41 = y10/k46;  // dwdp[55]
    dflux_J22_dk41 = y13/k46;  // dwdp[56]
    dflux_J24_dk41 = y9/k46;  // dwdp[58]
    dflux_J30_dk41 = y2/k46;  // dwdp[59]
    dflux_J31_dk41 = y5/k46;  // dwdp[60]
    dflux_J35_dk41 = y14/k46;  // dwdp[61]
    dflux_J36_dk41 = y0/k46;  // dwdp[62]
    dflux_J48_dk41 = y11/k46;  // dwdp[63]
    dflux_J56_dk41 = y7/k46;  // dwdp[64]
    dflux_J57_dk41 = y8/k46;  // dwdp[65]
    dflux_J58_dk41 = y12/k46;  // dwdp[66]
    dflux_J59_dk41 = y15/k46;  // dwdp[67]
    dflux_J0_dk42 = y3/k46;  // dwdp[68]
    dflux_J10_dk42 = y6/k46;  // dwdp[70]
    dflux_J13_dk42 = y1/k46;  // dwdp[71]
    dflux_J14_dk42 = y4/k46;  // dwdp[72]
    dflux_J18_dk42 = y10/k46;  // dwdp[73]
    dflux_J22_dk42 = y13/k46;  // dwdp[74]
    dflux_J24_dk42 = y9/k46;  // dwdp[75]
    dflux_J30_dk42 = y2/k46;  // dwdp[76]
    dflux_J31_dk42 = y5/k46;  // dwdp[77]
    dflux_J35_dk42 = y14/k46;  // dwdp[78]
    dflux_J36_dk42 = y0/k46;  // dwdp[79]
    dflux_J48_dk42 = y11/k46;  // dwdp[80]
    dflux_J56_dk42 = y7/k46;  // dwdp[81]
    dflux_J57_dk42 = y8/k46;  // dwdp[82]
    dflux_J58_dk42 = y12/k46;  // dwdp[83]
    dflux_J59_dk42 = y15/k46;  // dwdp[84]
    dflux_J0_dk43 = y3/k46;  // dwdp[85]
    dflux_J10_dk43 = y6/k46;  // dwdp[87]
    dflux_J13_dk43 = y1/k46;  // dwdp[88]
    dflux_J14_dk43 = y4/k46;  // dwdp[89]
    dflux_J18_dk43 = y10/k46;  // dwdp[90]
    dflux_J22_dk43 = y13/k46;  // dwdp[91]
    dflux_J24_dk43 = y9/k46;  // dwdp[92]
    dflux_J30_dk43 = y2/k46;  // dwdp[94]
    dflux_J31_dk43 = y5/k46;  // dwdp[95]
    dflux_J35_dk43 = y14/k46;  // dwdp[96]
    dflux_J36_dk43 = y0/k46;  // dwdp[97]
    dflux_J48_dk43 = y11/k46;  // dwdp[98]
    dflux_J56_dk43 = y7/k46;  // dwdp[99]
    dflux_J57_dk43 = y8/k46;  // dwdp[100]
    dflux_J58_dk43 = y12/k46;  // dwdp[101]
    dflux_J59_dk43 = y15/k46;  // dwdp[102]
    dflux_J0_dk44 = y3/k46;  // dwdp[103]
    dflux_J10_dk44 = y6/k46;  // dwdp[104]
    dflux_J13_dk44 = y1/k46;  // dwdp[106]
    dflux_J14_dk44 = y4/k46;  // dwdp[107]
    dflux_J18_dk44 = y10/k46;  // dwdp[108]
    dflux_J22_dk44 = y13/k46;  // dwdp[109]
    dflux_J24_dk44 = y9/k46;  // dwdp[110]
    dflux_J30_dk44 = y2/k46;  // dwdp[111]
    dflux_J31_dk44 = y5/k46;  // dwdp[112]
    dflux_J35_dk44 = y14/k46;  // dwdp[113]
    dflux_J36_dk44 = y0/k46;  // dwdp[114]
    dflux_J48_dk44 = y11/k46;  // dwdp[115]
    dflux_J56_dk44 = y7/k46;  // dwdp[116]
    dflux_J57_dk44 = y8/k46;  // dwdp[117]
    dflux_J58_dk44 = y12/k46;  // dwdp[118]
    dflux_J59_dk44 = y15/k46;  // dwdp[119]
    dflux_J0_dk45 = y3/k46;  // dwdp[120]
    dflux_J10_dk45 = y6/k46;  // dwdp[121]
    dflux_J13_dk45 = y1/k46;  // dwdp[122]
    dflux_J14_dk45 = y4/k46;  // dwdp[123]
    dflux_J18_dk45 = y10/k46;  // dwdp[124]
    dflux_J22_dk45 = y13/k46;  // dwdp[125]
    dflux_J24_dk45 = y9/k46;  // dwdp[126]
    dflux_J30_dk45 = y2/k46;  // dwdp[128]
    dflux_J31_dk45 = y5/k46;  // dwdp[129]
    dflux_J35_dk45 = y14/k46;  // dwdp[130]
    dflux_J36_dk45 = y0/k46;  // dwdp[131]
    dflux_J48_dk45 = y11/k46;  // dwdp[132]
    dflux_J56_dk45 = y7/k46;  // dwdp[134]
    dflux_J57_dk45 = y8/k46;  // dwdp[135]
    dflux_J58_dk45 = y12/k46;  // dwdp[136]
    dflux_J59_dk45 = y15/k46;  // dwdp[137]
    dflux_J0_dk46 = -y3*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/std::pow(k46, 2);  // dwdp[138]
    dflux_J10_dk46 = -y6*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/std::pow(k46, 2);  // dwdp[141]
    dflux_J13_dk46 = -y1*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/std::pow(k46, 2);  // dwdp[144]
    dflux_J14_dk46 = -y4*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/std::pow(k46, 2);  // dwdp[145]
    dflux_J18_dk46 = -y10*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/std::pow(k46, 2);  // dwdp[146]
    dflux_J22_dk46 = -y13*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/std::pow(k46, 2);  // dwdp[147]
    dflux_J24_dk46 = -y9*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/std::pow(k46, 2);  // dwdp[149]
    dflux_J30_dk46 = -y2*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/std::pow(k46, 2);  // dwdp[152]
    dflux_J31_dk46 = -y5*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/std::pow(k46, 2);  // dwdp[153]
    dflux_J35_dk46 = -y14*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/std::pow(k46, 2);  // dwdp[154]
    dflux_J36_dk46 = -y0*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/std::pow(k46, 2);  // dwdp[155]
    dflux_J48_dk46 = -y11*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/std::pow(k46, 2);  // dwdp[156]
    dflux_J56_dk46 = -y7*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/std::pow(k46, 2);  // dwdp[160]
    dflux_J57_dk46 = -y8*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/std::pow(k46, 2);  // dwdp[161]
    dflux_J58_dk46 = -y12*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/std::pow(k46, 2);  // dwdp[162]
    dflux_J59_dk46 = -y15*(k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/std::pow(k46, 2);  // dwdp[163]
    dflux_J1_dk19 = y0*y1*y11/(k35*k37 + k35*y0 + k37*y1 + y0*y1);  // dwdp[164]
    dflux_J2_dk19 = y0*y1*y11/(k35*k37 + k35*y0 + k37*y1 + y0*y1);  // dwdp[165]
    dflux_J3_dk19 = y0*y1*y11/(k35*k37 + k35*y0 + k37*y1 + y0*y1);  // dwdp[166]
    dflux_J1_dk35 = -k19*y0*y1*y11*(k37 + y0)/std::pow(k35*k37 + k35*y0 + k37*y1 + y0*y1, 2);  // dwdp[167]
    dflux_J2_dk35 = -k19*y0*y1*y11*(k37 + y0)/std::pow(k35*k37 + k35*y0 + k37*y1 + y0*y1, 2);  // dwdp[168]
    dflux_J3_dk35 = -k19*y0*y1*y11*(k37 + y0)/std::pow(k35*k37 + k35*y0 + k37*y1 + y0*y1, 2);  // dwdp[169]
    dflux_J1_dk37 = -k19*y0*y1*y11*(k35 + y1)/std::pow(k35*k37 + k35*y0 + k37*y1 + y0*y1, 2);  // dwdp[170]
    dflux_J2_dk37 = -k19*y0*y1*y11*(k35 + y1)/std::pow(k35*k37 + k35*y0 + k37*y1 + y0*y1, 2);  // dwdp[171]
    dflux_J3_dk37 = -k19*y0*y1*y11*(k35 + y1)/std::pow(k35*k37 + k35*y0 + k37*y1 + y0*y1, 2);  // dwdp[172]
    dflux_J6_dk18 = y13*y2*y3/(k32*k34 + k32*y2 + k34*y3 + y2*y3);  // dwdp[175]
    dflux_J7_dk18 = y13*y2*y3/(k32*k34 + k32*y2 + k34*y3 + y2*y3);  // dwdp[176]
    dflux_J8_dk18 = y13*y2*y3/(k32*k34 + k32*y2 + k34*y3 + y2*y3);  // dwdp[177]
    dflux_J9_dk18 = y13*y2*y3/(k32*k34 + k32*y2 + k34*y3 + y2*y3);  // dwdp[178]
    dflux_J6_dk32 = -k18*y13*y2*y3*(k34 + y2)/std::pow(k32*k34 + k32*y2 + k34*y3 + y2*y3, 2);  // dwdp[179]
    dflux_J7_dk32 = -k18*y13*y2*y3*(k34 + y2)/std::pow(k32*k34 + k32*y2 + k34*y3 + y2*y3, 2);  // dwdp[180]
    dflux_J8_dk32 = -k18*y13*y2*y3*(k34 + y2)/std::pow(k32*k34 + k32*y2 + k34*y3 + y2*y3, 2);  // dwdp[181]
    dflux_J9_dk32 = -k18*y13*y2*y3*(k34 + y2)/std::pow(k32*k34 + k32*y2 + k34*y3 + y2*y3, 2);  // dwdp[182]
    dflux_J6_dk34 = -k18*y13*y2*y3*(k32 + y3)/std::pow(k32*k34 + k32*y2 + k34*y3 + y2*y3, 2);  // dwdp[183]
    dflux_J7_dk34 = -k18*y13*y2*y3*(k32 + y3)/std::pow(k32*k34 + k32*y2 + k34*y3 + y2*y3, 2);  // dwdp[184]
    dflux_J8_dk34 = -k18*y13*y2*y3*(k32 + y3)/std::pow(k32*k34 + k32*y2 + k34*y3 + y2*y3, 2);  // dwdp[185]
    dflux_J9_dk34 = -k18*y13*y2*y3*(k32 + y3)/std::pow(k32*k34 + k32*y2 + k34*y3 + y2*y3, 2);  // dwdp[186]
    dflux_J15_dk36 = -k36*y11*y2/std::pow(k36 + y2, 2) + y11*y2/(k36 + y2);  // dwdp[189]
    dflux_J16_dk36 = -k36*y11*y2/std::pow(k36 + y2, 2) + y11*y2/(k36 + y2);  // dwdp[190]
    dflux_J17_dk36 = -k36*y11*y2/std::pow(k36 + y2, 2) + y11*y2/(k36 + y2);  // dwdp[191]
    dflux_J19_dk14 = y1*y12*y6/(k26*k27 + k26*y1 + k27*y6 + y1*y6);  // dwdp[192]
    dflux_J20_dk14 = y1*y12*y6/(k26*k27 + k26*y1 + k27*y6 + y1*y6);  // dwdp[193]
    dflux_J21_dk14 = y1*y12*y6/(k26*k27 + k26*y1 + k27*y6 + y1*y6);  // dwdp[194]
    dflux_J19_dk26 = -k14*y1*y12*y6*(k27 + y1)/std::pow(k26*k27 + k26*y1 + k27*y6 + y1*y6, 2);  // dwdp[195]
    dflux_J20_dk26 = -k14*y1*y12*y6*(k27 + y1)/std::pow(k26*k27 + k26*y1 + k27*y6 + y1*y6, 2);  // dwdp[196]
    dflux_J21_dk26 = -k14*y1*y12*y6*(k27 + y1)/std::pow(k26*k27 + k26*y1 + k27*y6 + y1*y6, 2);  // dwdp[197]
    dflux_J19_dk27 = -k14*y1*y12*y6*(k26 + y6)/std::pow(k26*k27 + k26*y1 + k27*y6 + y1*y6, 2);  // dwdp[198]
    dflux_J20_dk27 = -k14*y1*y12*y6*(k26 + y6)/std::pow(k26*k27 + k26*y1 + k27*y6 + y1*y6, 2);  // dwdp[199]
    dflux_J21_dk27 = -k14*y1*y12*y6*(k26 + y6)/std::pow(k26*k27 + k26*y1 + k27*y6 + y1*y6, 2);  // dwdp[200]
    dflux_J26_dk25 = -k25*y12*y7/std::pow(k25 + y7, 2) + y12*y7/(k25 + y7);  // dwdp[203]
    dflux_J27_dk25 = -k25*y12*y7/std::pow(k25 + y7, 2) + y12*y7/(k25 + y7);  // dwdp[204]
    dflux_J28_dk25 = -k25*y12*y7/std::pow(k25 + y7, 2) + y12*y7/(k25 + y7);  // dwdp[205]
    dflux_J32_dk11 = y15*std::pow(y5, 2)/(std::pow(k22, 2) + 2*k22*y5 + std::pow(y5, 2));  // dwdp[207]
    dflux_J33_dk11 = y15*std::pow(y5, 2)/(std::pow(k22, 2) + 2*k22*y5 + std::pow(y5, 2));  // dwdp[208]
    dflux_J34_dk11 = y15*std::pow(y5, 2)/(std::pow(k22, 2) + 2*k22*y5 + std::pow(y5, 2));  // dwdp[209]
    dflux_J32_dk22 = -k11*y15*std::pow(y5, 2)*(2*k22 + 2*y5)/std::pow(std::pow(k22, 2) + 2*k22*y5 + std::pow(y5, 2), 2);  // dwdp[210]
    dflux_J33_dk22 = -k11*y15*std::pow(y5, 2)*(2*k22 + 2*y5)/std::pow(std::pow(k22, 2) + 2*k22*y5 + std::pow(y5, 2), 2);  // dwdp[211]
    dflux_J34_dk22 = -k11*y15*std::pow(y5, 2)*(2*k22 + 2*y5)/std::pow(std::pow(k22, 2) + 2*k22*y5 + std::pow(y5, 2), 2);  // dwdp[212]
    dflux_J37_dk17 = y13*y4*y5/(k31*k33 + k31*y4 + k33*y5 + y4*y5);  // dwdp[213]
    dflux_J38_dk17 = y13*y4*y5/(k31*k33 + k31*y4 + k33*y5 + y4*y5);  // dwdp[214]
    dflux_J39_dk17 = y13*y4*y5/(k31*k33 + k31*y4 + k33*y5 + y4*y5);  // dwdp[215]
    dflux_J40_dk17 = y13*y4*y5/(k31*k33 + k31*y4 + k33*y5 + y4*y5);  // dwdp[216]
    dflux_J37_dk31 = -k17*y13*y4*y5*(k33 + y4)/std::pow(k31*k33 + k31*y4 + k33*y5 + y4*y5, 2);  // dwdp[217]
    dflux_J38_dk31 = -k17*y13*y4*y5*(k33 + y4)/std::pow(k31*k33 + k31*y4 + k33*y5 + y4*y5, 2);  // dwdp[218]
    dflux_J39_dk31 = -k17*y13*y4*y5*(k33 + y4)/std::pow(k31*k33 + k31*y4 + k33*y5 + y4*y5, 2);  // dwdp[219]
    dflux_J40_dk31 = -k17*y13*y4*y5*(k33 + y4)/std::pow(k31*k33 + k31*y4 + k33*y5 + y4*y5, 2);  // dwdp[220]
    dflux_J37_dk33 = -k17*y13*y4*y5*(k31 + y5)/std::pow(k31*k33 + k31*y4 + k33*y5 + y4*y5, 2);  // dwdp[221]
    dflux_J38_dk33 = -k17*y13*y4*y5*(k31 + y5)/std::pow(k31*k33 + k31*y4 + k33*y5 + y4*y5, 2);  // dwdp[222]
    dflux_J39_dk33 = -k17*y13*y4*y5*(k31 + y5)/std::pow(k31*k33 + k31*y4 + k33*y5 + y4*y5, 2);  // dwdp[223]
    dflux_J40_dk33 = -k17*y13*y4*y5*(k31 + y5)/std::pow(k31*k33 + k31*y4 + k33*y5 + y4*y5, 2);  // dwdp[224]
    dflux_J41_dk12 = y15*y3*y7/(k23*k24 + k23*y3 + k24*y7 + y3*y7);  // dwdp[225]
    dflux_J42_dk12 = y15*y3*y7/(k23*k24 + k23*y3 + k24*y7 + y3*y7);  // dwdp[226]
    dflux_J43_dk12 = y15*y3*y7/(k23*k24 + k23*y3 + k24*y7 + y3*y7);  // dwdp[227]
    dflux_J41_dk23 = -k12*y15*y3*y7*(k24 + y3)/std::pow(k23*k24 + k23*y3 + k24*y7 + y3*y7, 2);  // dwdp[228]
    dflux_J42_dk23 = -k12*y15*y3*y7*(k24 + y3)/std::pow(k23*k24 + k23*y3 + k24*y7 + y3*y7, 2);  // dwdp[229]
    dflux_J43_dk23 = -k12*y15*y3*y7*(k24 + y3)/std::pow(k23*k24 + k23*y3 + k24*y7 + y3*y7, 2);  // dwdp[230]
    dflux_J41_dk24 = -k12*y15*y3*y7*(k23 + y7)/std::pow(k23*k24 + k23*y3 + k24*y7 + y3*y7, 2);  // dwdp[231]
    dflux_J42_dk24 = -k12*y15*y3*y7*(k23 + y7)/std::pow(k23*k24 + k23*y3 + k24*y7 + y3*y7, 2);  // dwdp[232]
    dflux_J43_dk24 = -k12*y15*y3*y7*(k23 + y7)/std::pow(k23*k24 + k23*y3 + k24*y7 + y3*y7, 2);  // dwdp[233]
    dflux_J44_dk15 = y14*y5*y8*std::pow(1 + y5/k21, -k10)/(k28*k29 + k28*y8 + k29*y5 + y5*y8);  // dwdp[234]
    dflux_J45_dk15 = y14*y5*y8*std::pow(1 + y5/k21, -k10)/(k28*k29 + k28*y8 + k29*y5 + y5*y8);  // dwdp[235]
    dflux_J46_dk15 = y14*y5*y8*std::pow(1 + y5/k21, -k10)/(k28*k29 + k28*y8 + k29*y5 + y5*y8);  // dwdp[236]
    dflux_J47_dk15 = y14*y5*y8*std::pow(1 + y5/k21, -k10)/(k28*k29 + k28*y8 + k29*y5 + y5*y8);  // dwdp[237]
    dflux_J44_dk28 = -k15*y14*y5*y8*std::pow(1 + y5/k21, -k10)*(k29 + y8)/std::pow(k28*k29 + k28*y8 + k29*y5 + y5*y8, 2);  // dwdp[238]
    dflux_J45_dk28 = -k15*y14*y5*y8*std::pow(1 + y5/k21, -k10)*(k29 + y8)/std::pow(k28*k29 + k28*y8 + k29*y5 + y5*y8, 2);  // dwdp[239]
    dflux_J46_dk28 = -k15*y14*y5*y8*std::pow(1 + y5/k21, -k10)*(k29 + y8)/std::pow(k28*k29 + k28*y8 + k29*y5 + y5*y8, 2);  // dwdp[240]
    dflux_J47_dk28 = -k15*y14*y5*y8*std::pow(1 + y5/k21, -k10)*(k29 + y8)/std::pow(k28*k29 + k28*y8 + k29*y5 + y5*y8, 2);  // dwdp[241]
    dflux_J44_dk29 = -k15*y14*y5*y8*std::pow(1 + y5/k21, -k10)*(k28 + y5)/std::pow(k28*k29 + k28*y8 + k29*y5 + y5*y8, 2);  // dwdp[242]
    dflux_J45_dk29 = -k15*y14*y5*y8*std::pow(1 + y5/k21, -k10)*(k28 + y5)/std::pow(k28*k29 + k28*y8 + k29*y5 + y5*y8, 2);  // dwdp[243]
    dflux_J46_dk29 = -k15*y14*y5*y8*std::pow(1 + y5/k21, -k10)*(k28 + y5)/std::pow(k28*k29 + k28*y8 + k29*y5 + y5*y8, 2);  // dwdp[244]
    dflux_J47_dk29 = -k15*y14*y5*y8*std::pow(1 + y5/k21, -k10)*(k28 + y5)/std::pow(k28*k29 + k28*y8 + k29*y5 + y5*y8, 2);  // dwdp[245]
    dflux_J50_dk29 = -k16*y14*y4*y8*std::pow(1 + y5/k21, -k10)*(k30 + y4)/std::pow(k29*k30 + k29*y4 + k30*y8 + y4*y8, 2);  // dwdp[246]
    dflux_J51_dk29 = -k16*y14*y4*y8*std::pow(1 + y5/k21, -k10)*(k30 + y4)/std::pow(k29*k30 + k29*y4 + k30*y8 + y4*y8, 2);  // dwdp[247]
    dflux_J52_dk29 = -k16*y14*y4*y8*std::pow(1 + y5/k21, -k10)*(k30 + y4)/std::pow(k29*k30 + k29*y4 + k30*y8 + y4*y8, 2);  // dwdp[248]
    dflux_J53_dk29 = -k16*y14*y4*y8*std::pow(1 + y5/k21, -k10)*(k30 + y4)/std::pow(k29*k30 + k29*y4 + k30*y8 + y4*y8, 2);  // dwdp[249]
    dflux_J44_dk21 = k10*k15*y14*std::pow(y5, 2)*y8*std::pow(1 + y5/k21, -k10 - 1)/(std::pow(k21, 2)*(k28*k29 + k28*y8 + k29*y5 + y5*y8));  // dwdp[250]
    dflux_J45_dk21 = k10*k15*y14*std::pow(y5, 2)*y8*std::pow(1 + y5/k21, -k10 - 1)/(std::pow(k21, 2)*(k28*k29 + k28*y8 + k29*y5 + y5*y8));  // dwdp[251]
    dflux_J46_dk21 = k10*k15*y14*std::pow(y5, 2)*y8*std::pow(1 + y5/k21, -k10 - 1)/(std::pow(k21, 2)*(k28*k29 + k28*y8 + k29*y5 + y5*y8));  // dwdp[252]
    dflux_J47_dk21 = k10*k15*y14*std::pow(y5, 2)*y8*std::pow(1 + y5/k21, -k10 - 1)/(std::pow(k21, 2)*(k28*k29 + k28*y8 + k29*y5 + y5*y8));  // dwdp[253]
    dflux_J50_dk21 = k10*k16*y14*y4*y5*y8*std::pow(1 + y5/k21, -k10 - 1)/(std::pow(k21, 2)*(k29*k30 + k29*y4 + k30*y8 + y4*y8));  // dwdp[254]
    dflux_J51_dk21 = k10*k16*y14*y4*y5*y8*std::pow(1 + y5/k21, -k10 - 1)/(std::pow(k21, 2)*(k29*k30 + k29*y4 + k30*y8 + y4*y8));  // dwdp[255]
    dflux_J52_dk21 = k10*k16*y14*y4*y5*y8*std::pow(1 + y5/k21, -k10 - 1)/(std::pow(k21, 2)*(k29*k30 + k29*y4 + k30*y8 + y4*y8));  // dwdp[256]
    dflux_J53_dk21 = k10*k16*y14*y4*y5*y8*std::pow(1 + y5/k21, -k10 - 1)/(std::pow(k21, 2)*(k29*k30 + k29*y4 + k30*y8 + y4*y8));  // dwdp[257]
    dflux_J44_dk10 = k15*y14*y5*y8*((y5/k21 == -1) ? (
       1 + y5/k21
    )
    : (
       -std::pow(1 + y5/k21, -k10)*std::log(1 + y5/k21)
    ))/(k28*k29 + k28*y8 + k29*y5 + y5*y8);  // dwdp[258]
    dflux_J45_dk10 = k15*y14*y5*y8*((y5/k21 == -1) ? (
       1 + y5/k21
    )
    : (
       -std::pow(1 + y5/k21, -k10)*std::log(1 + y5/k21)
    ))/(k28*k29 + k28*y8 + k29*y5 + y5*y8);  // dwdp[259]
    dflux_J46_dk10 = k15*y14*y5*y8*((y5/k21 == -1) ? (
       1 + y5/k21
    )
    : (
       -std::pow(1 + y5/k21, -k10)*std::log(1 + y5/k21)
    ))/(k28*k29 + k28*y8 + k29*y5 + y5*y8);  // dwdp[260]
    dflux_J47_dk10 = k15*y14*y5*y8*((y5/k21 == -1) ? (
       1 + y5/k21
    )
    : (
       -std::pow(1 + y5/k21, -k10)*std::log(1 + y5/k21)
    ))/(k28*k29 + k28*y8 + k29*y5 + y5*y8);  // dwdp[261]
    dflux_J50_dk10 = k16*y14*y4*y8*((y5/k21 == -1) ? (
       1 + y5/k21
    )
    : (
       -std::pow(1 + y5/k21, -k10)*std::log(1 + y5/k21)
    ))/(k29*k30 + k29*y4 + k30*y8 + y4*y8);  // dwdp[262]
    dflux_J51_dk10 = k16*y14*y4*y8*((y5/k21 == -1) ? (
       1 + y5/k21
    )
    : (
       -std::pow(1 + y5/k21, -k10)*std::log(1 + y5/k21)
    ))/(k29*k30 + k29*y4 + k30*y8 + y4*y8);  // dwdp[263]
    dflux_J52_dk10 = k16*y14*y4*y8*((y5/k21 == -1) ? (
       1 + y5/k21
    )
    : (
       -std::pow(1 + y5/k21, -k10)*std::log(1 + y5/k21)
    ))/(k29*k30 + k29*y4 + k30*y8 + y4*y8);  // dwdp[264]
    dflux_J53_dk10 = k16*y14*y4*y8*((y5/k21 == -1) ? (
       1 + y5/k21
    )
    : (
       -std::pow(1 + y5/k21, -k10)*std::log(1 + y5/k21)
    ))/(k29*k30 + k29*y4 + k30*y8 + y4*y8);  // dwdp[265]
    dflux_J50_dk16 = y14*y4*y8*std::pow(1 + y5/k21, -k10)/(k29*k30 + k29*y4 + k30*y8 + y4*y8);  // dwdp[267]
    dflux_J51_dk16 = y14*y4*y8*std::pow(1 + y5/k21, -k10)/(k29*k30 + k29*y4 + k30*y8 + y4*y8);  // dwdp[268]
    dflux_J52_dk16 = y14*y4*y8*std::pow(1 + y5/k21, -k10)/(k29*k30 + k29*y4 + k30*y8 + y4*y8);  // dwdp[269]
    dflux_J53_dk16 = y14*y4*y8*std::pow(1 + y5/k21, -k10)/(k29*k30 + k29*y4 + k30*y8 + y4*y8);  // dwdp[270]
    dflux_J50_dk30 = -k16*y14*y4*y8*std::pow(1 + y5/k21, -k10)*(k29 + y8)/std::pow(k29*k30 + k29*y4 + k30*y8 + y4*y8, 2);  // dwdp[271]
    dflux_J51_dk30 = -k16*y14*y4*y8*std::pow(1 + y5/k21, -k10)*(k29 + y8)/std::pow(k29*k30 + k29*y4 + k30*y8 + y4*y8, 2);  // dwdp[272]
    dflux_J52_dk30 = -k16*y14*y4*y8*std::pow(1 + y5/k21, -k10)*(k29 + y8)/std::pow(k29*k30 + k29*y4 + k30*y8 + y4*y8, 2);  // dwdp[273]
    dflux_J53_dk30 = -k16*y14*y4*y8*std::pow(1 + y5/k21, -k10)*(k29 + y8)/std::pow(k29*k30 + k29*y4 + k30*y8 + y4*y8, 2);  // dwdp[274]
}

} // namespace model_name_final_ADP_forward
} // namespace amici
