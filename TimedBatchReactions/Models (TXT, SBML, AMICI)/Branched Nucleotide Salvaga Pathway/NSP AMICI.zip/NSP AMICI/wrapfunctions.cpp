#include "wrapfunctions.h"
#include "name_final_ADP_forward.h"
#include "amici/model.h"

namespace amici {
namespace generic_model {

std::unique_ptr<amici::Model> getModel() {
    return std::unique_ptr<amici::Model>(
        new amici::model_name_final_ADP_forward::Model_name_final_ADP_forward()
    );
}

} // namespace generic_model

} // namespace amici
