#include "amici/symbolic_functions.h"
#include "amici/defines.h"
#include "sundials/sundials_types.h"

#include <gsl/gsl-lite.hpp>
#include <algorithm>

#include "x.h"
#include "p.h"
#include "w.h"

namespace amici {
namespace model_name_final_ADP_forward {

void y_name_final_ADP_forward(realtype *y, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w){
    y[0] = y3;
    y[1] = y0;
    y[2] = y11;
    y[3] = y1;
    y[4] = y2;
    y[5] = y6;
    y[6] = y13;
    y[7] = y4;
    y[8] = y5;
    y[9] = y8;
    y[10] = y10;
    y[11] = y12;
    y[12] = y7;
    y[13] = y9;
    y[14] = y15;
    y[15] = y14;
    y[16] = 1.0;
}

} // namespace model_name_final_ADP_forward
} // namespace amici
