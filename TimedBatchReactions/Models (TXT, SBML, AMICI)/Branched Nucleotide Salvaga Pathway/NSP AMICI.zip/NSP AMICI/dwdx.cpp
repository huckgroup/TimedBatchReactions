#include "amici/sundials_matrix_wrapper.h"
#include "sundials/sundials_types.h"

#include <array>
#include <algorithm>

namespace amici {
namespace model_name_final_ADP_forward {

static constexpr std::array<sunindextype, 17> dwdx_colptrs_name_final_ADP_forward_ = {
    0, 8, 12, 19, 26, 34, 38, 47, 56, 72, 81, 82, 89, 96, 97, 104, 113
};

void dwdx_colptrs_name_final_ADP_forward(SUNMatrixWrapper &dwdx){
    dwdx.set_indexptrs(gsl::make_span(dwdx_colptrs_name_final_ADP_forward_));
}
} // namespace model_name_final_ADP_forward
} // namespace amici

#include "amici/sundials_matrix_wrapper.h"
#include "sundials/sundials_types.h"

#include <array>
#include <algorithm>

namespace amici {
namespace model_name_final_ADP_forward {

static constexpr std::array<sunindextype, 113> dwdx_rowvals_name_final_ADP_forward_ = {
    0, 6, 7, 8, 9, 41, 42, 43, 1, 2, 3, 36, 1, 2, 3, 15, 16, 17, 48, 1, 2, 3, 13, 19, 20, 21, 6, 7, 8, 9, 15, 16, 17, 30, 10, 19, 20, 21, 6, 7, 8, 9, 22, 37, 38, 39, 40, 14, 37, 38, 39, 40, 50, 51, 52, 53, 31, 32, 33, 34, 37, 38, 39, 40, 44, 45, 46, 47, 50, 51, 52, 53, 44, 45, 46, 47, 50, 51, 52, 53, 57, 18, 19, 20, 21, 26, 27, 28, 58, 26, 27, 28, 41, 42, 43, 56, 24, 32, 33, 34, 41, 42, 43, 59, 35, 44, 45, 46, 47, 50, 51, 52, 53
};

void dwdx_rowvals_name_final_ADP_forward(SUNMatrixWrapper &dwdx){
    dwdx.set_indexvals(gsl::make_span(dwdx_rowvals_name_final_ADP_forward_));
}
} // namespace model_name_final_ADP_forward
} // namespace amici




#include "amici/symbolic_functions.h"
#include "amici/defines.h"
#include "sundials/sundials_types.h"

#include <gsl/gsl-lite.hpp>
#include <algorithm>

#include "x.h"
#include "p.h"
#include "w.h"
#include "dwdx.h"

namespace amici {
namespace model_name_final_ADP_forward {

void dwdx_name_final_ADP_forward(realtype *dwdx, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w, const realtype *tcl, const realtype *spl, bool include_static){
    // static expressions
    if (include_static) {
        dflux_J0_dy3 = (k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // dwdx[0]
        dflux_J36_dy0 = (k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // dwdx[11]
        dflux_J48_dy11 = (k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // dwdx[18]
        dflux_J13_dy1 = (k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // dwdx[22]
        dflux_J30_dy2 = (k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // dwdx[33]
        dflux_J10_dy6 = (k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // dwdx[34]
        dflux_J22_dy13 = (k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // dwdx[42]
        dflux_J14_dy4 = (k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // dwdx[47]
        dflux_J31_dy5 = (k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // dwdx[56]
        dflux_J57_dy8 = (k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // dwdx[80]
        dflux_J18_dy10 = (k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // dwdx[81]
        dflux_J58_dy12 = (k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // dwdx[88]
        dflux_J56_dy7 = (k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // dwdx[95]
        dflux_J24_dy9 = (k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // dwdx[96]
        dflux_J59_dy15 = (k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // dwdx[103]
        dflux_J35_dy14 = (k38 + k39 + k40 + k41 + k42 + k43 + k44 + k45)/k46;  // dwdx[104]
    }

    // dynamic expressions
    dflux_J6_dy3 = -k18*y13*y2*y3*(k34 + y2)/std::pow(k32*k34 + k32*y2 + k34*y3 + y2*y3, 2) + k18*y13*y2/(k32*k34 + k32*y2 + k34*y3 + y2*y3);  // dwdx[1]
    dflux_J7_dy3 = -k18*y13*y2*y3*(k34 + y2)/std::pow(k32*k34 + k32*y2 + k34*y3 + y2*y3, 2) + k18*y13*y2/(k32*k34 + k32*y2 + k34*y3 + y2*y3);  // dwdx[2]
    dflux_J8_dy3 = -k18*y13*y2*y3*(k34 + y2)/std::pow(k32*k34 + k32*y2 + k34*y3 + y2*y3, 2) + k18*y13*y2/(k32*k34 + k32*y2 + k34*y3 + y2*y3);  // dwdx[3]
    dflux_J9_dy3 = -k18*y13*y2*y3*(k34 + y2)/std::pow(k32*k34 + k32*y2 + k34*y3 + y2*y3, 2) + k18*y13*y2/(k32*k34 + k32*y2 + k34*y3 + y2*y3);  // dwdx[4]
    dflux_J41_dy3 = -k12*y15*y3*y7*(k23 + y7)/std::pow(k23*k24 + k23*y3 + k24*y7 + y3*y7, 2) + k12*y15*y7/(k23*k24 + k23*y3 + k24*y7 + y3*y7);  // dwdx[5]
    dflux_J42_dy3 = -k12*y15*y3*y7*(k23 + y7)/std::pow(k23*k24 + k23*y3 + k24*y7 + y3*y7, 2) + k12*y15*y7/(k23*k24 + k23*y3 + k24*y7 + y3*y7);  // dwdx[6]
    dflux_J43_dy3 = -k12*y15*y3*y7*(k23 + y7)/std::pow(k23*k24 + k23*y3 + k24*y7 + y3*y7, 2) + k12*y15*y7/(k23*k24 + k23*y3 + k24*y7 + y3*y7);  // dwdx[7]
    dflux_J1_dy0 = -k19*y0*y1*y11*(k35 + y1)/std::pow(k35*k37 + k35*y0 + k37*y1 + y0*y1, 2) + k19*y1*y11/(k35*k37 + k35*y0 + k37*y1 + y0*y1);  // dwdx[8]
    dflux_J2_dy0 = -k19*y0*y1*y11*(k35 + y1)/std::pow(k35*k37 + k35*y0 + k37*y1 + y0*y1, 2) + k19*y1*y11/(k35*k37 + k35*y0 + k37*y1 + y0*y1);  // dwdx[9]
    dflux_J3_dy0 = -k19*y0*y1*y11*(k35 + y1)/std::pow(k35*k37 + k35*y0 + k37*y1 + y0*y1, 2) + k19*y1*y11/(k35*k37 + k35*y0 + k37*y1 + y0*y1);  // dwdx[10]
    dflux_J1_dy11 = k19*y0*y1/(k35*k37 + k35*y0 + k37*y1 + y0*y1);  // dwdx[12]
    dflux_J2_dy11 = k19*y0*y1/(k35*k37 + k35*y0 + k37*y1 + y0*y1);  // dwdx[13]
    dflux_J3_dy11 = k19*y0*y1/(k35*k37 + k35*y0 + k37*y1 + y0*y1);  // dwdx[14]
    dflux_J15_dy11 = k36*y2/(k36 + y2);  // dwdx[15]
    dflux_J16_dy11 = k36*y2/(k36 + y2);  // dwdx[16]
    dflux_J17_dy11 = k36*y2/(k36 + y2);  // dwdx[17]
    dflux_J1_dy1 = -k19*y0*y1*y11*(k37 + y0)/std::pow(k35*k37 + k35*y0 + k37*y1 + y0*y1, 2) + k19*y0*y11/(k35*k37 + k35*y0 + k37*y1 + y0*y1);  // dwdx[19]
    dflux_J2_dy1 = -k19*y0*y1*y11*(k37 + y0)/std::pow(k35*k37 + k35*y0 + k37*y1 + y0*y1, 2) + k19*y0*y11/(k35*k37 + k35*y0 + k37*y1 + y0*y1);  // dwdx[20]
    dflux_J3_dy1 = -k19*y0*y1*y11*(k37 + y0)/std::pow(k35*k37 + k35*y0 + k37*y1 + y0*y1, 2) + k19*y0*y11/(k35*k37 + k35*y0 + k37*y1 + y0*y1);  // dwdx[21]
    dflux_J19_dy1 = -k14*y1*y12*y6*(k26 + y6)/std::pow(k26*k27 + k26*y1 + k27*y6 + y1*y6, 2) + k14*y12*y6/(k26*k27 + k26*y1 + k27*y6 + y1*y6);  // dwdx[23]
    dflux_J20_dy1 = -k14*y1*y12*y6*(k26 + y6)/std::pow(k26*k27 + k26*y1 + k27*y6 + y1*y6, 2) + k14*y12*y6/(k26*k27 + k26*y1 + k27*y6 + y1*y6);  // dwdx[24]
    dflux_J21_dy1 = -k14*y1*y12*y6*(k26 + y6)/std::pow(k26*k27 + k26*y1 + k27*y6 + y1*y6, 2) + k14*y12*y6/(k26*k27 + k26*y1 + k27*y6 + y1*y6);  // dwdx[25]
    dflux_J6_dy2 = -k18*y13*y2*y3*(k32 + y3)/std::pow(k32*k34 + k32*y2 + k34*y3 + y2*y3, 2) + k18*y13*y3/(k32*k34 + k32*y2 + k34*y3 + y2*y3);  // dwdx[26]
    dflux_J7_dy2 = -k18*y13*y2*y3*(k32 + y3)/std::pow(k32*k34 + k32*y2 + k34*y3 + y2*y3, 2) + k18*y13*y3/(k32*k34 + k32*y2 + k34*y3 + y2*y3);  // dwdx[27]
    dflux_J8_dy2 = -k18*y13*y2*y3*(k32 + y3)/std::pow(k32*k34 + k32*y2 + k34*y3 + y2*y3, 2) + k18*y13*y3/(k32*k34 + k32*y2 + k34*y3 + y2*y3);  // dwdx[28]
    dflux_J9_dy2 = -k18*y13*y2*y3*(k32 + y3)/std::pow(k32*k34 + k32*y2 + k34*y3 + y2*y3, 2) + k18*y13*y3/(k32*k34 + k32*y2 + k34*y3 + y2*y3);  // dwdx[29]
    dflux_J15_dy2 = -k36*y11*y2/std::pow(k36 + y2, 2) + k36*y11/(k36 + y2);  // dwdx[30]
    dflux_J16_dy2 = -k36*y11*y2/std::pow(k36 + y2, 2) + k36*y11/(k36 + y2);  // dwdx[31]
    dflux_J17_dy2 = -k36*y11*y2/std::pow(k36 + y2, 2) + k36*y11/(k36 + y2);  // dwdx[32]
    dflux_J19_dy6 = -k14*y1*y12*y6*(k27 + y1)/std::pow(k26*k27 + k26*y1 + k27*y6 + y1*y6, 2) + k14*y1*y12/(k26*k27 + k26*y1 + k27*y6 + y1*y6);  // dwdx[35]
    dflux_J20_dy6 = -k14*y1*y12*y6*(k27 + y1)/std::pow(k26*k27 + k26*y1 + k27*y6 + y1*y6, 2) + k14*y1*y12/(k26*k27 + k26*y1 + k27*y6 + y1*y6);  // dwdx[36]
    dflux_J21_dy6 = -k14*y1*y12*y6*(k27 + y1)/std::pow(k26*k27 + k26*y1 + k27*y6 + y1*y6, 2) + k14*y1*y12/(k26*k27 + k26*y1 + k27*y6 + y1*y6);  // dwdx[37]
    dflux_J6_dy13 = k18*y2*y3/(k32*k34 + k32*y2 + k34*y3 + y2*y3);  // dwdx[38]
    dflux_J7_dy13 = k18*y2*y3/(k32*k34 + k32*y2 + k34*y3 + y2*y3);  // dwdx[39]
    dflux_J8_dy13 = k18*y2*y3/(k32*k34 + k32*y2 + k34*y3 + y2*y3);  // dwdx[40]
    dflux_J9_dy13 = k18*y2*y3/(k32*k34 + k32*y2 + k34*y3 + y2*y3);  // dwdx[41]
    dflux_J37_dy13 = k17*y4*y5/(k31*k33 + k31*y4 + k33*y5 + y4*y5);  // dwdx[43]
    dflux_J38_dy13 = k17*y4*y5/(k31*k33 + k31*y4 + k33*y5 + y4*y5);  // dwdx[44]
    dflux_J39_dy13 = k17*y4*y5/(k31*k33 + k31*y4 + k33*y5 + y4*y5);  // dwdx[45]
    dflux_J40_dy13 = k17*y4*y5/(k31*k33 + k31*y4 + k33*y5 + y4*y5);  // dwdx[46]
    dflux_J37_dy4 = -k17*y13*y4*y5*(k31 + y5)/std::pow(k31*k33 + k31*y4 + k33*y5 + y4*y5, 2) + k17*y13*y5/(k31*k33 + k31*y4 + k33*y5 + y4*y5);  // dwdx[48]
    dflux_J38_dy4 = -k17*y13*y4*y5*(k31 + y5)/std::pow(k31*k33 + k31*y4 + k33*y5 + y4*y5, 2) + k17*y13*y5/(k31*k33 + k31*y4 + k33*y5 + y4*y5);  // dwdx[49]
    dflux_J39_dy4 = -k17*y13*y4*y5*(k31 + y5)/std::pow(k31*k33 + k31*y4 + k33*y5 + y4*y5, 2) + k17*y13*y5/(k31*k33 + k31*y4 + k33*y5 + y4*y5);  // dwdx[50]
    dflux_J40_dy4 = -k17*y13*y4*y5*(k31 + y5)/std::pow(k31*k33 + k31*y4 + k33*y5 + y4*y5, 2) + k17*y13*y5/(k31*k33 + k31*y4 + k33*y5 + y4*y5);  // dwdx[51]
    dflux_J50_dy4 = -k16*y14*y4*y8*std::pow(1 + y5/k21, -k10)*(k29 + y8)/std::pow(k29*k30 + k29*y4 + k30*y8 + y4*y8, 2) + k16*y14*y8*std::pow(1 + y5/k21, -k10)/(k29*k30 + k29*y4 + k30*y8 + y4*y8);  // dwdx[52]
    dflux_J51_dy4 = -k16*y14*y4*y8*std::pow(1 + y5/k21, -k10)*(k29 + y8)/std::pow(k29*k30 + k29*y4 + k30*y8 + y4*y8, 2) + k16*y14*y8*std::pow(1 + y5/k21, -k10)/(k29*k30 + k29*y4 + k30*y8 + y4*y8);  // dwdx[53]
    dflux_J52_dy4 = -k16*y14*y4*y8*std::pow(1 + y5/k21, -k10)*(k29 + y8)/std::pow(k29*k30 + k29*y4 + k30*y8 + y4*y8, 2) + k16*y14*y8*std::pow(1 + y5/k21, -k10)/(k29*k30 + k29*y4 + k30*y8 + y4*y8);  // dwdx[54]
    dflux_J53_dy4 = -k16*y14*y4*y8*std::pow(1 + y5/k21, -k10)*(k29 + y8)/std::pow(k29*k30 + k29*y4 + k30*y8 + y4*y8, 2) + k16*y14*y8*std::pow(1 + y5/k21, -k10)/(k29*k30 + k29*y4 + k30*y8 + y4*y8);  // dwdx[55]
    dflux_J32_dy5 = -k11*y15*std::pow(y5, 2)*(2*k22 + 2*y5)/std::pow(std::pow(k22, 2) + 2*k22*y5 + std::pow(y5, 2), 2) + 2*k11*y15*y5/(std::pow(k22, 2) + 2*k22*y5 + std::pow(y5, 2));  // dwdx[57]
    dflux_J33_dy5 = -k11*y15*std::pow(y5, 2)*(2*k22 + 2*y5)/std::pow(std::pow(k22, 2) + 2*k22*y5 + std::pow(y5, 2), 2) + 2*k11*y15*y5/(std::pow(k22, 2) + 2*k22*y5 + std::pow(y5, 2));  // dwdx[58]
    dflux_J34_dy5 = -k11*y15*std::pow(y5, 2)*(2*k22 + 2*y5)/std::pow(std::pow(k22, 2) + 2*k22*y5 + std::pow(y5, 2), 2) + 2*k11*y15*y5/(std::pow(k22, 2) + 2*k22*y5 + std::pow(y5, 2));  // dwdx[59]
    dflux_J37_dy5 = -k17*y13*y4*y5*(k33 + y4)/std::pow(k31*k33 + k31*y4 + k33*y5 + y4*y5, 2) + k17*y13*y4/(k31*k33 + k31*y4 + k33*y5 + y4*y5);  // dwdx[60]
    dflux_J38_dy5 = -k17*y13*y4*y5*(k33 + y4)/std::pow(k31*k33 + k31*y4 + k33*y5 + y4*y5, 2) + k17*y13*y4/(k31*k33 + k31*y4 + k33*y5 + y4*y5);  // dwdx[61]
    dflux_J39_dy5 = -k17*y13*y4*y5*(k33 + y4)/std::pow(k31*k33 + k31*y4 + k33*y5 + y4*y5, 2) + k17*y13*y4/(k31*k33 + k31*y4 + k33*y5 + y4*y5);  // dwdx[62]
    dflux_J40_dy5 = -k17*y13*y4*y5*(k33 + y4)/std::pow(k31*k33 + k31*y4 + k33*y5 + y4*y5, 2) + k17*y13*y4/(k31*k33 + k31*y4 + k33*y5 + y4*y5);  // dwdx[63]
    dflux_J44_dy5 = -k10*k15*y14*y5*y8*std::pow(1 + y5/k21, -k10 - 1)/(k21*(k28*k29 + k28*y8 + k29*y5 + y5*y8)) - k15*y14*y5*y8*std::pow(1 + y5/k21, -k10)*(k29 + y8)/std::pow(k28*k29 + k28*y8 + k29*y5 + y5*y8, 2) + k15*y14*y8*std::pow(1 + y5/k21, -k10)/(k28*k29 + k28*y8 + k29*y5 + y5*y8);  // dwdx[64]
    dflux_J45_dy5 = -k10*k15*y14*y5*y8*std::pow(1 + y5/k21, -k10 - 1)/(k21*(k28*k29 + k28*y8 + k29*y5 + y5*y8)) - k15*y14*y5*y8*std::pow(1 + y5/k21, -k10)*(k29 + y8)/std::pow(k28*k29 + k28*y8 + k29*y5 + y5*y8, 2) + k15*y14*y8*std::pow(1 + y5/k21, -k10)/(k28*k29 + k28*y8 + k29*y5 + y5*y8);  // dwdx[65]
    dflux_J46_dy5 = -k10*k15*y14*y5*y8*std::pow(1 + y5/k21, -k10 - 1)/(k21*(k28*k29 + k28*y8 + k29*y5 + y5*y8)) - k15*y14*y5*y8*std::pow(1 + y5/k21, -k10)*(k29 + y8)/std::pow(k28*k29 + k28*y8 + k29*y5 + y5*y8, 2) + k15*y14*y8*std::pow(1 + y5/k21, -k10)/(k28*k29 + k28*y8 + k29*y5 + y5*y8);  // dwdx[66]
    dflux_J47_dy5 = -k10*k15*y14*y5*y8*std::pow(1 + y5/k21, -k10 - 1)/(k21*(k28*k29 + k28*y8 + k29*y5 + y5*y8)) - k15*y14*y5*y8*std::pow(1 + y5/k21, -k10)*(k29 + y8)/std::pow(k28*k29 + k28*y8 + k29*y5 + y5*y8, 2) + k15*y14*y8*std::pow(1 + y5/k21, -k10)/(k28*k29 + k28*y8 + k29*y5 + y5*y8);  // dwdx[67]
    dflux_J50_dy5 = -k10*k16*y14*y4*y8*std::pow(1 + y5/k21, -k10 - 1)/(k21*(k29*k30 + k29*y4 + k30*y8 + y4*y8));  // dwdx[68]
    dflux_J51_dy5 = -k10*k16*y14*y4*y8*std::pow(1 + y5/k21, -k10 - 1)/(k21*(k29*k30 + k29*y4 + k30*y8 + y4*y8));  // dwdx[69]
    dflux_J52_dy5 = -k10*k16*y14*y4*y8*std::pow(1 + y5/k21, -k10 - 1)/(k21*(k29*k30 + k29*y4 + k30*y8 + y4*y8));  // dwdx[70]
    dflux_J53_dy5 = -k10*k16*y14*y4*y8*std::pow(1 + y5/k21, -k10 - 1)/(k21*(k29*k30 + k29*y4 + k30*y8 + y4*y8));  // dwdx[71]
    dflux_J44_dy8 = -k15*y14*y5*y8*std::pow(1 + y5/k21, -k10)*(k28 + y5)/std::pow(k28*k29 + k28*y8 + k29*y5 + y5*y8, 2) + k15*y14*y5*std::pow(1 + y5/k21, -k10)/(k28*k29 + k28*y8 + k29*y5 + y5*y8);  // dwdx[72]
    dflux_J45_dy8 = -k15*y14*y5*y8*std::pow(1 + y5/k21, -k10)*(k28 + y5)/std::pow(k28*k29 + k28*y8 + k29*y5 + y5*y8, 2) + k15*y14*y5*std::pow(1 + y5/k21, -k10)/(k28*k29 + k28*y8 + k29*y5 + y5*y8);  // dwdx[73]
    dflux_J46_dy8 = -k15*y14*y5*y8*std::pow(1 + y5/k21, -k10)*(k28 + y5)/std::pow(k28*k29 + k28*y8 + k29*y5 + y5*y8, 2) + k15*y14*y5*std::pow(1 + y5/k21, -k10)/(k28*k29 + k28*y8 + k29*y5 + y5*y8);  // dwdx[74]
    dflux_J47_dy8 = -k15*y14*y5*y8*std::pow(1 + y5/k21, -k10)*(k28 + y5)/std::pow(k28*k29 + k28*y8 + k29*y5 + y5*y8, 2) + k15*y14*y5*std::pow(1 + y5/k21, -k10)/(k28*k29 + k28*y8 + k29*y5 + y5*y8);  // dwdx[75]
    dflux_J50_dy8 = -k16*y14*y4*y8*std::pow(1 + y5/k21, -k10)*(k30 + y4)/std::pow(k29*k30 + k29*y4 + k30*y8 + y4*y8, 2) + k16*y14*y4*std::pow(1 + y5/k21, -k10)/(k29*k30 + k29*y4 + k30*y8 + y4*y8);  // dwdx[76]
    dflux_J51_dy8 = -k16*y14*y4*y8*std::pow(1 + y5/k21, -k10)*(k30 + y4)/std::pow(k29*k30 + k29*y4 + k30*y8 + y4*y8, 2) + k16*y14*y4*std::pow(1 + y5/k21, -k10)/(k29*k30 + k29*y4 + k30*y8 + y4*y8);  // dwdx[77]
    dflux_J52_dy8 = -k16*y14*y4*y8*std::pow(1 + y5/k21, -k10)*(k30 + y4)/std::pow(k29*k30 + k29*y4 + k30*y8 + y4*y8, 2) + k16*y14*y4*std::pow(1 + y5/k21, -k10)/(k29*k30 + k29*y4 + k30*y8 + y4*y8);  // dwdx[78]
    dflux_J53_dy8 = -k16*y14*y4*y8*std::pow(1 + y5/k21, -k10)*(k30 + y4)/std::pow(k29*k30 + k29*y4 + k30*y8 + y4*y8, 2) + k16*y14*y4*std::pow(1 + y5/k21, -k10)/(k29*k30 + k29*y4 + k30*y8 + y4*y8);  // dwdx[79]
    dflux_J19_dy12 = k14*y1*y6/(k26*k27 + k26*y1 + k27*y6 + y1*y6);  // dwdx[82]
    dflux_J20_dy12 = k14*y1*y6/(k26*k27 + k26*y1 + k27*y6 + y1*y6);  // dwdx[83]
    dflux_J21_dy12 = k14*y1*y6/(k26*k27 + k26*y1 + k27*y6 + y1*y6);  // dwdx[84]
    dflux_J26_dy12 = k25*y7/(k25 + y7);  // dwdx[85]
    dflux_J27_dy12 = k25*y7/(k25 + y7);  // dwdx[86]
    dflux_J28_dy12 = k25*y7/(k25 + y7);  // dwdx[87]
    dflux_J26_dy7 = -k25*y12*y7/std::pow(k25 + y7, 2) + k25*y12/(k25 + y7);  // dwdx[89]
    dflux_J27_dy7 = -k25*y12*y7/std::pow(k25 + y7, 2) + k25*y12/(k25 + y7);  // dwdx[90]
    dflux_J28_dy7 = -k25*y12*y7/std::pow(k25 + y7, 2) + k25*y12/(k25 + y7);  // dwdx[91]
    dflux_J41_dy7 = -k12*y15*y3*y7*(k24 + y3)/std::pow(k23*k24 + k23*y3 + k24*y7 + y3*y7, 2) + k12*y15*y3/(k23*k24 + k23*y3 + k24*y7 + y3*y7);  // dwdx[92]
    dflux_J42_dy7 = -k12*y15*y3*y7*(k24 + y3)/std::pow(k23*k24 + k23*y3 + k24*y7 + y3*y7, 2) + k12*y15*y3/(k23*k24 + k23*y3 + k24*y7 + y3*y7);  // dwdx[93]
    dflux_J43_dy7 = -k12*y15*y3*y7*(k24 + y3)/std::pow(k23*k24 + k23*y3 + k24*y7 + y3*y7, 2) + k12*y15*y3/(k23*k24 + k23*y3 + k24*y7 + y3*y7);  // dwdx[94]
    dflux_J32_dy15 = k11*std::pow(y5, 2)/(std::pow(k22, 2) + 2*k22*y5 + std::pow(y5, 2));  // dwdx[97]
    dflux_J33_dy15 = k11*std::pow(y5, 2)/(std::pow(k22, 2) + 2*k22*y5 + std::pow(y5, 2));  // dwdx[98]
    dflux_J34_dy15 = k11*std::pow(y5, 2)/(std::pow(k22, 2) + 2*k22*y5 + std::pow(y5, 2));  // dwdx[99]
    dflux_J41_dy15 = k12*y3*y7/(k23*k24 + k23*y3 + k24*y7 + y3*y7);  // dwdx[100]
    dflux_J42_dy15 = k12*y3*y7/(k23*k24 + k23*y3 + k24*y7 + y3*y7);  // dwdx[101]
    dflux_J43_dy15 = k12*y3*y7/(k23*k24 + k23*y3 + k24*y7 + y3*y7);  // dwdx[102]
    dflux_J44_dy14 = k15*y5*y8*std::pow(1 + y5/k21, -k10)/(k28*k29 + k28*y8 + k29*y5 + y5*y8);  // dwdx[105]
    dflux_J45_dy14 = k15*y5*y8*std::pow(1 + y5/k21, -k10)/(k28*k29 + k28*y8 + k29*y5 + y5*y8);  // dwdx[106]
    dflux_J46_dy14 = k15*y5*y8*std::pow(1 + y5/k21, -k10)/(k28*k29 + k28*y8 + k29*y5 + y5*y8);  // dwdx[107]
    dflux_J47_dy14 = k15*y5*y8*std::pow(1 + y5/k21, -k10)/(k28*k29 + k28*y8 + k29*y5 + y5*y8);  // dwdx[108]
    dflux_J50_dy14 = k16*y4*y8*std::pow(1 + y5/k21, -k10)/(k29*k30 + k29*y4 + k30*y8 + y4*y8);  // dwdx[109]
    dflux_J51_dy14 = k16*y4*y8*std::pow(1 + y5/k21, -k10)/(k29*k30 + k29*y4 + k30*y8 + y4*y8);  // dwdx[110]
    dflux_J52_dy14 = k16*y4*y8*std::pow(1 + y5/k21, -k10)/(k29*k30 + k29*y4 + k30*y8 + y4*y8);  // dwdx[111]
    dflux_J53_dy14 = k16*y4*y8*std::pow(1 + y5/k21, -k10)/(k29*k30 + k29*y4 + k30*y8 + y4*y8);  // dwdx[112]
}

} // namespace model_name_final_ADP_forward
} // namespace amici
