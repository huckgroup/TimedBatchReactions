#include "wrapfunctions.h"
#include "PPP_GH_ALLOSTERICS_ADP_NN.h"
#include "amici/model.h"

namespace amici {
namespace generic_model {

std::unique_ptr<amici::Model> getModel() {
    return std::unique_ptr<amici::Model>(
        new amici::model_PPP_GH_ALLOSTERICS_ADP_NN::Model_PPP_GH_ALLOSTERICS_ADP_NN()
    );
}

} // namespace generic_model

} // namespace amici
