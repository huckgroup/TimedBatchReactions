#include "amici/symbolic_functions.h"
#include "amici/defines.h"
#include "sundials/sundials_types.h"

#include <gsl/gsl-lite.hpp>
#include <algorithm>

#include "x_rdata.h"

namespace amici {
namespace model_PPP_GH_ALLOSTERICS_ADP_NN {

void x_solver_PPP_GH_ALLOSTERICS_ADP_NN(realtype *x_solver, const realtype *x_rdata){
    x_solver[0] = y0;
    x_solver[1] = y1;
    x_solver[2] = y14;
    x_solver[3] = y11;
    x_solver[4] = y10;
    x_solver[5] = y9;
    x_solver[6] = y4;
    x_solver[7] = y12;
    x_solver[8] = y7;
    x_solver[9] = y6;
    x_solver[10] = y8;
    x_solver[11] = y3;
    x_solver[12] = y13;
    x_solver[13] = y5;
    x_solver[14] = y16;
    x_solver[15] = y2;
    x_solver[16] = y15;
}

} // namespace model_PPP_GH_ALLOSTERICS_ADP_NN
} // namespace amici
