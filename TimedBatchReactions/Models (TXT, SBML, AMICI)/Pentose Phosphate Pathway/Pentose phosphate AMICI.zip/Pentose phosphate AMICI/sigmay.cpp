#include "amici/symbolic_functions.h"
#include "amici/defines.h"
#include "sundials/sundials_types.h"

#include <gsl/gsl-lite.hpp>
#include <algorithm>

#include "p.h"
#include "y.h"
#include "sigmay.h"

namespace amici {
namespace model_PPP_GH_ALLOSTERICS_ADP_NN {

void sigmay_PPP_GH_ALLOSTERICS_ADP_NN(realtype *sigmay, const realtype t, const realtype *p, const realtype *k, const realtype *y){
    sigma_yy0 = 1.0;  // sigmay[0]
    sigma_yy1 = 1.0;  // sigmay[1]
    sigma_yy14 = 1.0;  // sigmay[2]
    sigma_yy11 = 1.0;  // sigmay[3]
    sigma_yy10 = 1.0;  // sigmay[4]
    sigma_yy9 = 1.0;  // sigmay[5]
    sigma_yy4 = 1.0;  // sigmay[6]
    sigma_yy12 = 1.0;  // sigmay[7]
    sigma_yy7 = 1.0;  // sigmay[8]
    sigma_yy6 = 1.0;  // sigmay[9]
    sigma_yy8 = 1.0;  // sigmay[10]
    sigma_yy3 = 1.0;  // sigmay[11]
    sigma_yy13 = 1.0;  // sigmay[12]
    sigma_yy5 = 1.0;  // sigmay[13]
    sigma_yy16 = 1.0;  // sigmay[14]
    sigma_yy2 = 1.0;  // sigmay[15]
    sigma_yy15 = 1.0;  // sigmay[16]
    sigma_ydefault_compartment = 1.0;  // sigmay[17]
}

} // namespace model_PPP_GH_ALLOSTERICS_ADP_NN
} // namespace amici
