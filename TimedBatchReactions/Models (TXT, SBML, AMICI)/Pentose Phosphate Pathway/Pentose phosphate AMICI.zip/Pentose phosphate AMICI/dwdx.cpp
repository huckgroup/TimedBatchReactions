#include "amici/sundials_matrix_wrapper.h"
#include "sundials/sundials_types.h"

#include <array>
#include <algorithm>

namespace amici {
namespace model_PPP_GH_ALLOSTERICS_ADP_NN {

static constexpr std::array<sunindextype, 18> dwdx_colptrs_PPP_GH_ALLOSTERICS_ADP_NN_ = {
    0, 5, 14, 23, 28, 33, 40, 49, 58, 65, 74, 81, 90, 99, 106, 115, 124, 129
};

void dwdx_colptrs_PPP_GH_ALLOSTERICS_ADP_NN(SUNMatrixWrapper &dwdx){
    dwdx.set_indexptrs(gsl::make_span(dwdx_colptrs_PPP_GH_ALLOSTERICS_ADP_NN_));
}
} // namespace model_PPP_GH_ALLOSTERICS_ADP_NN
} // namespace amici

#include "amici/sundials_matrix_wrapper.h"
#include "sundials/sundials_types.h"

#include <array>
#include <algorithm>

namespace amici {
namespace model_PPP_GH_ALLOSTERICS_ADP_NN {

static constexpr std::array<sunindextype, 129> dwdx_rowvals_PPP_GH_ALLOSTERICS_ADP_NN_ = {
    27, 28, 29, 30, 57, 27, 28, 29, 30, 33, 34, 35, 36, 37, 1, 2, 3, 4, 34, 35, 36, 37, 39, 1, 2, 3, 4, 56, 1, 2, 3, 4, 55, 26, 34, 35, 36, 37, 65, 66, 5, 6, 7, 8, 10, 14, 15, 16, 17, 5, 6, 7, 8, 23, 49, 50, 51, 52, 5, 6, 7, 8, 54, 62, 63, 12, 49, 50, 51, 52, 70, 71, 72, 73, 20, 49, 50, 51, 52, 67, 68, 14, 15, 16, 17, 18, 45, 46, 47, 48, 14, 15, 16, 17, 61, 70, 71, 72, 73, 31, 32, 40, 70, 71, 72, 73, 27, 28, 29, 30, 44, 45, 46, 47, 48, 34, 35, 36, 37, 43, 45, 46, 47, 48, 65, 66, 67, 68, 69
};

void dwdx_rowvals_PPP_GH_ALLOSTERICS_ADP_NN(SUNMatrixWrapper &dwdx){
    dwdx.set_indexvals(gsl::make_span(dwdx_rowvals_PPP_GH_ALLOSTERICS_ADP_NN_));
}
} // namespace model_PPP_GH_ALLOSTERICS_ADP_NN
} // namespace amici




#include "amici/symbolic_functions.h"
#include "amici/defines.h"
#include "sundials/sundials_types.h"

#include <gsl/gsl-lite.hpp>
#include <algorithm>

#include "x.h"
#include "p.h"
#include "w.h"
#include "dwdx.h"

namespace amici {
namespace model_PPP_GH_ALLOSTERICS_ADP_NN {

void dwdx_PPP_GH_ALLOSTERICS_ADP_NN(realtype *dwdx, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *w, const realtype *tcl, const realtype *spl, bool include_static){
    // static expressions
    if (include_static) {
        dflux_J57_dy0 = (k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // dwdx[4]
        dflux_J33_dy1 = (k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // dwdx[9]
        dflux_J39_dy14 = (k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // dwdx[22]
        dflux_J56_dy11 = (k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // dwdx[27]
        dflux_J55_dy10 = (k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // dwdx[32]
        dflux_J26_dy9 = (k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // dwdx[33]
        dflux_J10_dy4 = (k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // dwdx[44]
        dflux_J23_dy12 = (k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // dwdx[53]
        dflux_J54_dy7 = (k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // dwdx[62]
        dflux_J62_dy7 = k28;  // dwdx[63]
        dflux_J63_dy7 = k28;  // dwdx[64]
        dflux_J12_dy6 = (k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // dwdx[65]
        dflux_J20_dy8 = (k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // dwdx[74]
        dflux_J18_dy3 = (k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // dwdx[85]
        dflux_J61_dy13 = (k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // dwdx[94]
        dflux_J31_dy5 = k29;  // dwdx[99]
        dflux_J32_dy5 = k29;  // dwdx[100]
        dflux_J40_dy5 = (k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // dwdx[101]
        dflux_J44_dy16 = (k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // dwdx[110]
        dflux_J43_dy2 = (k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // dwdx[119]
        dflux_J69_dy15 = (k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // dwdx[128]
    }

    // dynamic expressions
    dflux_J27_dy0 = -k23*y0*y1*y16*(k40 + y1)/std::pow(k40*k42 + k40*y0 + k42*y1 + y0*y1, 2) + k23*y1*y16/(k40*k42 + k40*y0 + k42*y1 + y0*y1);  // dwdx[0]
    dflux_J28_dy0 = -k23*y0*y1*y16*(k40 + y1)/std::pow(k40*k42 + k40*y0 + k42*y1 + y0*y1, 2) + k23*y1*y16/(k40*k42 + k40*y0 + k42*y1 + y0*y1);  // dwdx[1]
    dflux_J29_dy0 = -k23*y0*y1*y16*(k40 + y1)/std::pow(k40*k42 + k40*y0 + k42*y1 + y0*y1, 2) + k23*y1*y16/(k40*k42 + k40*y0 + k42*y1 + y0*y1);  // dwdx[2]
    dflux_J30_dy0 = -k23*y0*y1*y16*(k40 + y1)/std::pow(k40*k42 + k40*y0 + k42*y1 + y0*y1, 2) + k23*y1*y16/(k40*k42 + k40*y0 + k42*y1 + y0*y1);  // dwdx[3]
    dflux_J27_dy1 = -k23*y0*y1*y16*(k42 + y0)/std::pow(k40*k42 + k40*y0 + k42*y1 + y0*y1, 2) + k23*y0*y16/(k40*k42 + k40*y0 + k42*y1 + y0*y1);  // dwdx[5]
    dflux_J28_dy1 = -k23*y0*y1*y16*(k42 + y0)/std::pow(k40*k42 + k40*y0 + k42*y1 + y0*y1, 2) + k23*y0*y16/(k40*k42 + k40*y0 + k42*y1 + y0*y1);  // dwdx[6]
    dflux_J29_dy1 = -k23*y0*y1*y16*(k42 + y0)/std::pow(k40*k42 + k40*y0 + k42*y1 + y0*y1, 2) + k23*y0*y16/(k40*k42 + k40*y0 + k42*y1 + y0*y1);  // dwdx[7]
    dflux_J30_dy1 = -k23*y0*y1*y16*(k42 + y0)/std::pow(k40*k42 + k40*y0 + k42*y1 + y0*y1, 2) + k23*y0*y16/(k40*k42 + k40*y0 + k42*y1 + y0*y1);  // dwdx[8]
    dflux_J34_dy1 = -k27*y1*y14*y9*std::pow(1 + y2/k30, -k17)*(k48 + y9)/std::pow(k46*k48 + k46*y9 + k48*y1 + y1*y9, 2) + k27*y14*y9*std::pow(1 + y2/k30, -k17)/(k46*k48 + k46*y9 + k48*y1 + y1*y9);  // dwdx[10]
    dflux_J35_dy1 = -k27*y1*y14*y9*std::pow(1 + y2/k30, -k17)*(k48 + y9)/std::pow(k46*k48 + k46*y9 + k48*y1 + y1*y9, 2) + k27*y14*y9*std::pow(1 + y2/k30, -k17)/(k46*k48 + k46*y9 + k48*y1 + y1*y9);  // dwdx[11]
    dflux_J36_dy1 = -k27*y1*y14*y9*std::pow(1 + y2/k30, -k17)*(k48 + y9)/std::pow(k46*k48 + k46*y9 + k48*y1 + y1*y9, 2) + k27*y14*y9*std::pow(1 + y2/k30, -k17)/(k46*k48 + k46*y9 + k48*y1 + y1*y9);  // dwdx[12]
    dflux_J37_dy1 = -k27*y1*y14*y9*std::pow(1 + y2/k30, -k17)*(k48 + y9)/std::pow(k46*k48 + k46*y9 + k48*y1 + y1*y9, 2) + k27*y14*y9*std::pow(1 + y2/k30, -k17)/(k46*k48 + k46*y9 + k48*y1 + y1*y9);  // dwdx[13]
    dflux_J1_dy14 = k26*y10*y11/(k45*k47 + k45*y10 + k47*y11 + y10*y11);  // dwdx[14]
    dflux_J2_dy14 = k26*y10*y11/(k45*k47 + k45*y10 + k47*y11 + y10*y11);  // dwdx[15]
    dflux_J3_dy14 = k26*y10*y11/(k45*k47 + k45*y10 + k47*y11 + y10*y11);  // dwdx[16]
    dflux_J4_dy14 = k26*y10*y11/(k45*k47 + k45*y10 + k47*y11 + y10*y11);  // dwdx[17]
    dflux_J34_dy14 = k27*y1*y9*std::pow(1 + y2/k30, -k17)/(k46*k48 + k46*y9 + k48*y1 + y1*y9);  // dwdx[18]
    dflux_J35_dy14 = k27*y1*y9*std::pow(1 + y2/k30, -k17)/(k46*k48 + k46*y9 + k48*y1 + y1*y9);  // dwdx[19]
    dflux_J36_dy14 = k27*y1*y9*std::pow(1 + y2/k30, -k17)/(k46*k48 + k46*y9 + k48*y1 + y1*y9);  // dwdx[20]
    dflux_J37_dy14 = k27*y1*y9*std::pow(1 + y2/k30, -k17)/(k46*k48 + k46*y9 + k48*y1 + y1*y9);  // dwdx[21]
    dflux_J1_dy11 = -k26*y10*y11*y14*(k47 + y10)/std::pow(k45*k47 + k45*y10 + k47*y11 + y10*y11, 2) + k26*y10*y14/(k45*k47 + k45*y10 + k47*y11 + y10*y11);  // dwdx[23]
    dflux_J2_dy11 = -k26*y10*y11*y14*(k47 + y10)/std::pow(k45*k47 + k45*y10 + k47*y11 + y10*y11, 2) + k26*y10*y14/(k45*k47 + k45*y10 + k47*y11 + y10*y11);  // dwdx[24]
    dflux_J3_dy11 = -k26*y10*y11*y14*(k47 + y10)/std::pow(k45*k47 + k45*y10 + k47*y11 + y10*y11, 2) + k26*y10*y14/(k45*k47 + k45*y10 + k47*y11 + y10*y11);  // dwdx[25]
    dflux_J4_dy11 = -k26*y10*y11*y14*(k47 + y10)/std::pow(k45*k47 + k45*y10 + k47*y11 + y10*y11, 2) + k26*y10*y14/(k45*k47 + k45*y10 + k47*y11 + y10*y11);  // dwdx[26]
    dflux_J1_dy10 = -k26*y10*y11*y14*(k45 + y11)/std::pow(k45*k47 + k45*y10 + k47*y11 + y10*y11, 2) + k26*y11*y14/(k45*k47 + k45*y10 + k47*y11 + y10*y11);  // dwdx[28]
    dflux_J2_dy10 = -k26*y10*y11*y14*(k45 + y11)/std::pow(k45*k47 + k45*y10 + k47*y11 + y10*y11, 2) + k26*y11*y14/(k45*k47 + k45*y10 + k47*y11 + y10*y11);  // dwdx[29]
    dflux_J3_dy10 = -k26*y10*y11*y14*(k45 + y11)/std::pow(k45*k47 + k45*y10 + k47*y11 + y10*y11, 2) + k26*y11*y14/(k45*k47 + k45*y10 + k47*y11 + y10*y11);  // dwdx[30]
    dflux_J4_dy10 = -k26*y10*y11*y14*(k45 + y11)/std::pow(k45*k47 + k45*y10 + k47*y11 + y10*y11, 2) + k26*y11*y14/(k45*k47 + k45*y10 + k47*y11 + y10*y11);  // dwdx[31]
    dflux_J34_dy9 = -k27*y1*y14*y9*std::pow(1 + y2/k30, -k17)*(k46 + y1)/std::pow(k46*k48 + k46*y9 + k48*y1 + y1*y9, 2) + k27*y1*y14*std::pow(1 + y2/k30, -k17)/(k46*k48 + k46*y9 + k48*y1 + y1*y9);  // dwdx[34]
    dflux_J35_dy9 = -k27*y1*y14*y9*std::pow(1 + y2/k30, -k17)*(k46 + y1)/std::pow(k46*k48 + k46*y9 + k48*y1 + y1*y9, 2) + k27*y1*y14*std::pow(1 + y2/k30, -k17)/(k46*k48 + k46*y9 + k48*y1 + y1*y9);  // dwdx[35]
    dflux_J36_dy9 = -k27*y1*y14*y9*std::pow(1 + y2/k30, -k17)*(k46 + y1)/std::pow(k46*k48 + k46*y9 + k48*y1 + y1*y9, 2) + k27*y1*y14*std::pow(1 + y2/k30, -k17)/(k46*k48 + k46*y9 + k48*y1 + y1*y9);  // dwdx[36]
    dflux_J37_dy9 = -k27*y1*y14*y9*std::pow(1 + y2/k30, -k17)*(k46 + y1)/std::pow(k46*k48 + k46*y9 + k48*y1 + y1*y9, 2) + k27*y1*y14*std::pow(1 + y2/k30, -k17)/(k46*k48 + k46*y9 + k48*y1 + y1*y9);  // dwdx[37]
    dflux_J65_dy9 = -k43*y15*y9/std::pow(k43 + y9, 2) + k43*y15/(k43 + y9);  // dwdx[38]
    dflux_J66_dy9 = -k43*y15*y9/std::pow(k43 + y9, 2) + k43*y15/(k43 + y9);  // dwdx[39]
    dflux_J5_dy4 = -k18*y12*y4*y7*(k31 + y7)/std::pow(k31*k32 + k31*y4 + k32*y7 + y4*y7, 2) + k18*y12*y7/(k31*k32 + k31*y4 + k32*y7 + y4*y7);  // dwdx[40]
    dflux_J6_dy4 = -k18*y12*y4*y7*(k31 + y7)/std::pow(k31*k32 + k31*y4 + k32*y7 + y4*y7, 2) + k18*y12*y7/(k31*k32 + k31*y4 + k32*y7 + y4*y7);  // dwdx[41]
    dflux_J7_dy4 = -k18*y12*y4*y7*(k31 + y7)/std::pow(k31*k32 + k31*y4 + k32*y7 + y4*y7, 2) + k18*y12*y7/(k31*k32 + k31*y4 + k32*y7 + y4*y7);  // dwdx[42]
    dflux_J8_dy4 = -k18*y12*y4*y7*(k31 + y7)/std::pow(k31*k32 + k31*y4 + k32*y7 + y4*y7, 2) + k18*y12*y7/(k31*k32 + k31*y4 + k32*y7 + y4*y7);  // dwdx[43]
    dflux_J14_dy4 = -k21*y13*y3*y4*(k36 + y3)/std::pow(k36*k37 + k36*y4 + k37*y3 + y3*y4, 2) + k21*y13*y3/(k36*k37 + k36*y4 + k37*y3 + y3*y4);  // dwdx[45]
    dflux_J15_dy4 = -k21*y13*y3*y4*(k36 + y3)/std::pow(k36*k37 + k36*y4 + k37*y3 + y3*y4, 2) + k21*y13*y3/(k36*k37 + k36*y4 + k37*y3 + y3*y4);  // dwdx[46]
    dflux_J16_dy4 = -k21*y13*y3*y4*(k36 + y3)/std::pow(k36*k37 + k36*y4 + k37*y3 + y3*y4, 2) + k21*y13*y3/(k36*k37 + k36*y4 + k37*y3 + y3*y4);  // dwdx[47]
    dflux_J17_dy4 = -k21*y13*y3*y4*(k36 + y3)/std::pow(k36*k37 + k36*y4 + k37*y3 + y3*y4, 2) + k21*y13*y3/(k36*k37 + k36*y4 + k37*y3 + y3*y4);  // dwdx[48]
    dflux_J5_dy12 = k18*y4*y7/(k31*k32 + k31*y4 + k32*y7 + y4*y7);  // dwdx[49]
    dflux_J6_dy12 = k18*y4*y7/(k31*k32 + k31*y4 + k32*y7 + y4*y7);  // dwdx[50]
    dflux_J7_dy12 = k18*y4*y7/(k31*k32 + k31*y4 + k32*y7 + y4*y7);  // dwdx[51]
    dflux_J8_dy12 = k18*y4*y7/(k31*k32 + k31*y4 + k32*y7 + y4*y7);  // dwdx[52]
    dflux_J49_dy12 = k19*y6*y8/(k33*k34 + k33*y8 + k34*y6 + y6*y8);  // dwdx[54]
    dflux_J50_dy12 = k19*y6*y8/(k33*k34 + k33*y8 + k34*y6 + y6*y8);  // dwdx[55]
    dflux_J51_dy12 = k19*y6*y8/(k33*k34 + k33*y8 + k34*y6 + y6*y8);  // dwdx[56]
    dflux_J52_dy12 = k19*y6*y8/(k33*k34 + k33*y8 + k34*y6 + y6*y8);  // dwdx[57]
    dflux_J5_dy7 = -k18*y12*y4*y7*(k32 + y4)/std::pow(k31*k32 + k31*y4 + k32*y7 + y4*y7, 2) + k18*y12*y4/(k31*k32 + k31*y4 + k32*y7 + y4*y7);  // dwdx[58]
    dflux_J6_dy7 = -k18*y12*y4*y7*(k32 + y4)/std::pow(k31*k32 + k31*y4 + k32*y7 + y4*y7, 2) + k18*y12*y4/(k31*k32 + k31*y4 + k32*y7 + y4*y7);  // dwdx[59]
    dflux_J7_dy7 = -k18*y12*y4*y7*(k32 + y4)/std::pow(k31*k32 + k31*y4 + k32*y7 + y4*y7, 2) + k18*y12*y4/(k31*k32 + k31*y4 + k32*y7 + y4*y7);  // dwdx[60]
    dflux_J8_dy7 = -k18*y12*y4*y7*(k32 + y4)/std::pow(k31*k32 + k31*y4 + k32*y7 + y4*y7, 2) + k18*y12*y4/(k31*k32 + k31*y4 + k32*y7 + y4*y7);  // dwdx[61]
    dflux_J49_dy6 = -k19*y12*y6*y8*(k34 + y8)/std::pow(k33*k34 + k33*y8 + k34*y6 + y6*y8, 2) + k19*y12*y8/(k33*k34 + k33*y8 + k34*y6 + y6*y8);  // dwdx[66]
    dflux_J50_dy6 = -k19*y12*y6*y8*(k34 + y8)/std::pow(k33*k34 + k33*y8 + k34*y6 + y6*y8, 2) + k19*y12*y8/(k33*k34 + k33*y8 + k34*y6 + y6*y8);  // dwdx[67]
    dflux_J51_dy6 = -k19*y12*y6*y8*(k34 + y8)/std::pow(k33*k34 + k33*y8 + k34*y6 + y6*y8, 2) + k19*y12*y8/(k33*k34 + k33*y8 + k34*y6 + y6*y8);  // dwdx[68]
    dflux_J52_dy6 = -k19*y12*y6*y8*(k34 + y8)/std::pow(k33*k34 + k33*y8 + k34*y6 + y6*y8, 2) + k19*y12*y8/(k33*k34 + k33*y8 + k34*y6 + y6*y8);  // dwdx[69]
    dflux_J70_dy6 = -k20*y13*y5*y6*(k35 + y5)/std::pow(k35*k38 + k35*y6 + k38*y5 + y5*y6, 2) + k20*y13*y5/(k35*k38 + k35*y6 + k38*y5 + y5*y6);  // dwdx[70]
    dflux_J71_dy6 = -k20*y13*y5*y6*(k35 + y5)/std::pow(k35*k38 + k35*y6 + k38*y5 + y5*y6, 2) + k20*y13*y5/(k35*k38 + k35*y6 + k38*y5 + y5*y6);  // dwdx[71]
    dflux_J72_dy6 = -k20*y13*y5*y6*(k35 + y5)/std::pow(k35*k38 + k35*y6 + k38*y5 + y5*y6, 2) + k20*y13*y5/(k35*k38 + k35*y6 + k38*y5 + y5*y6);  // dwdx[72]
    dflux_J73_dy6 = -k20*y13*y5*y6*(k35 + y5)/std::pow(k35*k38 + k35*y6 + k38*y5 + y5*y6, 2) + k20*y13*y5/(k35*k38 + k35*y6 + k38*y5 + y5*y6);  // dwdx[73]
    dflux_J49_dy8 = -k19*y12*y6*y8*(k33 + y6)/std::pow(k33*k34 + k33*y8 + k34*y6 + y6*y8, 2) + k19*y12*y6/(k33*k34 + k33*y8 + k34*y6 + y6*y8);  // dwdx[75]
    dflux_J50_dy8 = -k19*y12*y6*y8*(k33 + y6)/std::pow(k33*k34 + k33*y8 + k34*y6 + y6*y8, 2) + k19*y12*y6/(k33*k34 + k33*y8 + k34*y6 + y6*y8);  // dwdx[76]
    dflux_J51_dy8 = -k19*y12*y6*y8*(k33 + y6)/std::pow(k33*k34 + k33*y8 + k34*y6 + y6*y8, 2) + k19*y12*y6/(k33*k34 + k33*y8 + k34*y6 + y6*y8);  // dwdx[77]
    dflux_J52_dy8 = -k19*y12*y6*y8*(k33 + y6)/std::pow(k33*k34 + k33*y8 + k34*y6 + y6*y8, 2) + k19*y12*y6/(k33*k34 + k33*y8 + k34*y6 + y6*y8);  // dwdx[78]
    dflux_J67_dy8 = -k44*y15*y8/std::pow(k44 + y8, 2) + k44*y15/(k44 + y8);  // dwdx[79]
    dflux_J68_dy8 = -k44*y15*y8/std::pow(k44 + y8, 2) + k44*y15/(k44 + y8);  // dwdx[80]
    dflux_J14_dy3 = -k21*y13*y3*y4*(k37 + y4)/std::pow(k36*k37 + k36*y4 + k37*y3 + y3*y4, 2) + k21*y13*y4/(k36*k37 + k36*y4 + k37*y3 + y3*y4);  // dwdx[81]
    dflux_J15_dy3 = -k21*y13*y3*y4*(k37 + y4)/std::pow(k36*k37 + k36*y4 + k37*y3 + y3*y4, 2) + k21*y13*y4/(k36*k37 + k36*y4 + k37*y3 + y3*y4);  // dwdx[82]
    dflux_J16_dy3 = -k21*y13*y3*y4*(k37 + y4)/std::pow(k36*k37 + k36*y4 + k37*y3 + y3*y4, 2) + k21*y13*y4/(k36*k37 + k36*y4 + k37*y3 + y3*y4);  // dwdx[83]
    dflux_J17_dy3 = -k21*y13*y3*y4*(k37 + y4)/std::pow(k36*k37 + k36*y4 + k37*y3 + y3*y4, 2) + k21*y13*y4/(k36*k37 + k36*y4 + k37*y3 + y3*y4);  // dwdx[84]
    dflux_J45_dy3 = -k22*y16*y2*y3*(k39 + y2)/std::pow(k39*k41 + k39*y3 + k41*y2 + y2*y3, 2) + k22*y16*y2/(k39*k41 + k39*y3 + k41*y2 + y2*y3);  // dwdx[86]
    dflux_J46_dy3 = -k22*y16*y2*y3*(k39 + y2)/std::pow(k39*k41 + k39*y3 + k41*y2 + y2*y3, 2) + k22*y16*y2/(k39*k41 + k39*y3 + k41*y2 + y2*y3);  // dwdx[87]
    dflux_J47_dy3 = -k22*y16*y2*y3*(k39 + y2)/std::pow(k39*k41 + k39*y3 + k41*y2 + y2*y3, 2) + k22*y16*y2/(k39*k41 + k39*y3 + k41*y2 + y2*y3);  // dwdx[88]
    dflux_J48_dy3 = -k22*y16*y2*y3*(k39 + y2)/std::pow(k39*k41 + k39*y3 + k41*y2 + y2*y3, 2) + k22*y16*y2/(k39*k41 + k39*y3 + k41*y2 + y2*y3);  // dwdx[89]
    dflux_J14_dy13 = k21*y3*y4/(k36*k37 + k36*y4 + k37*y3 + y3*y4);  // dwdx[90]
    dflux_J15_dy13 = k21*y3*y4/(k36*k37 + k36*y4 + k37*y3 + y3*y4);  // dwdx[91]
    dflux_J16_dy13 = k21*y3*y4/(k36*k37 + k36*y4 + k37*y3 + y3*y4);  // dwdx[92]
    dflux_J17_dy13 = k21*y3*y4/(k36*k37 + k36*y4 + k37*y3 + y3*y4);  // dwdx[93]
    dflux_J70_dy13 = k20*y5*y6/(k35*k38 + k35*y6 + k38*y5 + y5*y6);  // dwdx[95]
    dflux_J71_dy13 = k20*y5*y6/(k35*k38 + k35*y6 + k38*y5 + y5*y6);  // dwdx[96]
    dflux_J72_dy13 = k20*y5*y6/(k35*k38 + k35*y6 + k38*y5 + y5*y6);  // dwdx[97]
    dflux_J73_dy13 = k20*y5*y6/(k35*k38 + k35*y6 + k38*y5 + y5*y6);  // dwdx[98]
    dflux_J70_dy5 = -k20*y13*y5*y6*(k38 + y6)/std::pow(k35*k38 + k35*y6 + k38*y5 + y5*y6, 2) + k20*y13*y6/(k35*k38 + k35*y6 + k38*y5 + y5*y6);  // dwdx[102]
    dflux_J71_dy5 = -k20*y13*y5*y6*(k38 + y6)/std::pow(k35*k38 + k35*y6 + k38*y5 + y5*y6, 2) + k20*y13*y6/(k35*k38 + k35*y6 + k38*y5 + y5*y6);  // dwdx[103]
    dflux_J72_dy5 = -k20*y13*y5*y6*(k38 + y6)/std::pow(k35*k38 + k35*y6 + k38*y5 + y5*y6, 2) + k20*y13*y6/(k35*k38 + k35*y6 + k38*y5 + y5*y6);  // dwdx[104]
    dflux_J73_dy5 = -k20*y13*y5*y6*(k38 + y6)/std::pow(k35*k38 + k35*y6 + k38*y5 + y5*y6, 2) + k20*y13*y6/(k35*k38 + k35*y6 + k38*y5 + y5*y6);  // dwdx[105]
    dflux_J27_dy16 = k23*y0*y1/(k40*k42 + k40*y0 + k42*y1 + y0*y1);  // dwdx[106]
    dflux_J28_dy16 = k23*y0*y1/(k40*k42 + k40*y0 + k42*y1 + y0*y1);  // dwdx[107]
    dflux_J29_dy16 = k23*y0*y1/(k40*k42 + k40*y0 + k42*y1 + y0*y1);  // dwdx[108]
    dflux_J30_dy16 = k23*y0*y1/(k40*k42 + k40*y0 + k42*y1 + y0*y1);  // dwdx[109]
    dflux_J45_dy16 = k22*y2*y3/(k39*k41 + k39*y3 + k41*y2 + y2*y3);  // dwdx[111]
    dflux_J46_dy16 = k22*y2*y3/(k39*k41 + k39*y3 + k41*y2 + y2*y3);  // dwdx[112]
    dflux_J47_dy16 = k22*y2*y3/(k39*k41 + k39*y3 + k41*y2 + y2*y3);  // dwdx[113]
    dflux_J48_dy16 = k22*y2*y3/(k39*k41 + k39*y3 + k41*y2 + y2*y3);  // dwdx[114]
    dflux_J34_dy2 = -k17*k27*y1*y14*y9*std::pow(1 + y2/k30, -k17 - 1)/(k30*(k46*k48 + k46*y9 + k48*y1 + y1*y9));  // dwdx[115]
    dflux_J35_dy2 = -k17*k27*y1*y14*y9*std::pow(1 + y2/k30, -k17 - 1)/(k30*(k46*k48 + k46*y9 + k48*y1 + y1*y9));  // dwdx[116]
    dflux_J36_dy2 = -k17*k27*y1*y14*y9*std::pow(1 + y2/k30, -k17 - 1)/(k30*(k46*k48 + k46*y9 + k48*y1 + y1*y9));  // dwdx[117]
    dflux_J37_dy2 = -k17*k27*y1*y14*y9*std::pow(1 + y2/k30, -k17 - 1)/(k30*(k46*k48 + k46*y9 + k48*y1 + y1*y9));  // dwdx[118]
    dflux_J45_dy2 = -k22*y16*y2*y3*(k41 + y3)/std::pow(k39*k41 + k39*y3 + k41*y2 + y2*y3, 2) + k22*y16*y3/(k39*k41 + k39*y3 + k41*y2 + y2*y3);  // dwdx[120]
    dflux_J46_dy2 = -k22*y16*y2*y3*(k41 + y3)/std::pow(k39*k41 + k39*y3 + k41*y2 + y2*y3, 2) + k22*y16*y3/(k39*k41 + k39*y3 + k41*y2 + y2*y3);  // dwdx[121]
    dflux_J47_dy2 = -k22*y16*y2*y3*(k41 + y3)/std::pow(k39*k41 + k39*y3 + k41*y2 + y2*y3, 2) + k22*y16*y3/(k39*k41 + k39*y3 + k41*y2 + y2*y3);  // dwdx[122]
    dflux_J48_dy2 = -k22*y16*y2*y3*(k41 + y3)/std::pow(k39*k41 + k39*y3 + k41*y2 + y2*y3, 2) + k22*y16*y3/(k39*k41 + k39*y3 + k41*y2 + y2*y3);  // dwdx[123]
    dflux_J65_dy15 = k43*y9/(k43 + y9);  // dwdx[124]
    dflux_J66_dy15 = k43*y9/(k43 + y9);  // dwdx[125]
    dflux_J67_dy15 = k44*y8/(k44 + y8);  // dwdx[126]
    dflux_J68_dy15 = k44*y8/(k44 + y8);  // dwdx[127]
}

} // namespace model_PPP_GH_ALLOSTERICS_ADP_NN
} // namespace amici
