#include "amici/sundials_matrix_wrapper.h"
#include "sundials/sundials_types.h"

#include <array>
#include <algorithm>

namespace amici {
namespace model_PPP_GH_ALLOSTERICS_ADP_NN {

static constexpr std::array<std::array<sunindextype, 19>, 18> dJydy_colptrs_PPP_GH_ALLOSTERICS_ADP_NN_ = {{
    {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 
    {0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 
    {0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 
    {0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 
    {0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 
    {0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 
    {0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 
    {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1}, 
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1}, 
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1}, 
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1}, 
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1}, 
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1}, 
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1}, 
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1}, 
}};

void dJydy_colptrs_PPP_GH_ALLOSTERICS_ADP_NN(SUNMatrixWrapper &dJydy, int index){
    dJydy.set_indexptrs(gsl::make_span(dJydy_colptrs_PPP_GH_ALLOSTERICS_ADP_NN_[index]));
}
} // namespace model_PPP_GH_ALLOSTERICS_ADP_NN
} // namespace amici

#include "amici/sundials_matrix_wrapper.h"
#include "sundials/sundials_types.h"

#include <array>
#include <algorithm>

namespace amici {
namespace model_PPP_GH_ALLOSTERICS_ADP_NN {

static constexpr std::array<std::array<sunindextype, 1>, 18> dJydy_rowvals_PPP_GH_ALLOSTERICS_ADP_NN_ = {{
    {0}, 
    {0}, 
    {0}, 
    {0}, 
    {0}, 
    {0}, 
    {0}, 
    {0}, 
    {0}, 
    {0}, 
    {0}, 
    {0}, 
    {0}, 
    {0}, 
    {0}, 
    {0}, 
    {0}, 
    {0}, 
}};

void dJydy_rowvals_PPP_GH_ALLOSTERICS_ADP_NN(SUNMatrixWrapper &dJydy, int index){
    dJydy.set_indexvals(gsl::make_span(dJydy_rowvals_PPP_GH_ALLOSTERICS_ADP_NN_[index]));
}
} // namespace model_PPP_GH_ALLOSTERICS_ADP_NN
} // namespace amici




#include "amici/symbolic_functions.h"
#include "amici/defines.h"
#include "sundials/sundials_types.h"

#include <gsl/gsl-lite.hpp>
#include <algorithm>

#include "p.h"
#include "y.h"
#include "sigmay.h"
#include "my.h"
#include "dJydy.h"

namespace amici {
namespace model_PPP_GH_ALLOSTERICS_ADP_NN {

void dJydy_PPP_GH_ALLOSTERICS_ADP_NN(realtype *dJydy, const int iy, const realtype *p, const realtype *k, const realtype *y, const realtype *sigmay, const realtype *my){
    switch(iy) {
        case 0:
            dJydy[0] = (-1.0*myy0 + 1.0*yy0)/std::pow(sigma_yy0, 2);
            break;
        case 1:
            dJydy[0] = (-1.0*myy1 + 1.0*yy1)/std::pow(sigma_yy1, 2);
            break;
        case 2:
            dJydy[0] = (-1.0*myy14 + 1.0*yy14)/std::pow(sigma_yy14, 2);
            break;
        case 3:
            dJydy[0] = (-1.0*myy11 + 1.0*yy11)/std::pow(sigma_yy11, 2);
            break;
        case 4:
            dJydy[0] = (-1.0*myy10 + 1.0*yy10)/std::pow(sigma_yy10, 2);
            break;
        case 5:
            dJydy[0] = (-1.0*myy9 + 1.0*yy9)/std::pow(sigma_yy9, 2);
            break;
        case 6:
            dJydy[0] = (-1.0*myy4 + 1.0*yy4)/std::pow(sigma_yy4, 2);
            break;
        case 7:
            dJydy[0] = (-1.0*myy12 + 1.0*yy12)/std::pow(sigma_yy12, 2);
            break;
        case 8:
            dJydy[0] = (-1.0*myy7 + 1.0*yy7)/std::pow(sigma_yy7, 2);
            break;
        case 9:
            dJydy[0] = (-1.0*myy6 + 1.0*yy6)/std::pow(sigma_yy6, 2);
            break;
        case 10:
            dJydy[0] = (-1.0*myy8 + 1.0*yy8)/std::pow(sigma_yy8, 2);
            break;
        case 11:
            dJydy[0] = (-1.0*myy3 + 1.0*yy3)/std::pow(sigma_yy3, 2);
            break;
        case 12:
            dJydy[0] = (-1.0*myy13 + 1.0*yy13)/std::pow(sigma_yy13, 2);
            break;
        case 13:
            dJydy[0] = (-1.0*myy5 + 1.0*yy5)/std::pow(sigma_yy5, 2);
            break;
        case 14:
            dJydy[0] = (-1.0*myy16 + 1.0*yy16)/std::pow(sigma_yy16, 2);
            break;
        case 15:
            dJydy[0] = (-1.0*myy2 + 1.0*yy2)/std::pow(sigma_yy2, 2);
            break;
        case 16:
            dJydy[0] = (-1.0*myy15 + 1.0*yy15)/std::pow(sigma_yy15, 2);
            break;
        case 17:
            dJydy[0] = (-1.0*mydefault_compartment + 1.0*ydefault_compartment)/std::pow(sigma_ydefault_compartment, 2);
            break;
    }
}

} // namespace model_PPP_GH_ALLOSTERICS_ADP_NN
} // namespace amici
