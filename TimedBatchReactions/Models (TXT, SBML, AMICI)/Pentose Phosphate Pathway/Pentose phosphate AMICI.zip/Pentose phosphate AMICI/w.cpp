#include "amici/symbolic_functions.h"
#include "amici/defines.h"
#include "sundials/sundials_types.h"

#include <gsl/gsl-lite.hpp>
#include <algorithm>

#include "x.h"
#include "p.h"
#include "w.h"

namespace amici {
namespace model_PPP_GH_ALLOSTERICS_ADP_NN {

void w_PPP_GH_ALLOSTERICS_ADP_NN(realtype *w, const realtype t, const realtype *x, const realtype *p, const realtype *k, const realtype *h, const realtype *tcl, const realtype *spl, bool include_static){
    // static expressions
    if (include_static) {
        flux_J0 = k64*k8/k66;  // w[0]
        flux_J9 = k13*k56/k66;  // w[9]
        flux_J11 = k16*k54/k66;  // w[11]
        flux_J13 = k0*k62/k66;  // w[13]
        flux_J19 = k5*k53/k66;  // w[19]
        flux_J21 = k51*k9/k66;  // w[21]
        flux_J22 = k59*k7/k66;  // w[22]
        flux_J24 = k57*k6/k66;  // w[24]
        flux_J25 = k11*k60/k66;  // w[25]
        flux_J38 = k10*k49/k66;  // w[38]
        flux_J41 = k15*k55/k66;  // w[41]
        flux_J42 = k12*k63/k66;  // w[42]
        flux_J53 = k2*k58/k66;  // w[53]
        flux_J58 = k4*k65/k66;  // w[58]
        flux_J59 = k1*k50/k66;  // w[59]
        flux_J60 = k14*k61/k66;  // w[60]
        flux_J64 = k3*k52/k66;  // w[64]
    }

    // dynamic expressions
    flux_J1 = k26*y10*y11*y14/(k45*k47 + k45*y10 + k47*y11 + y10*y11);  // w[1]
    flux_J2 = k26*y10*y11*y14/(k45*k47 + k45*y10 + k47*y11 + y10*y11);  // w[2]
    flux_J3 = k26*y10*y11*y14/(k45*k47 + k45*y10 + k47*y11 + y10*y11);  // w[3]
    flux_J4 = k26*y10*y11*y14/(k45*k47 + k45*y10 + k47*y11 + y10*y11);  // w[4]
    flux_J5 = k18*y12*y4*y7/(k31*k32 + k31*y4 + k32*y7 + y4*y7);  // w[5]
    flux_J6 = k18*y12*y4*y7/(k31*k32 + k31*y4 + k32*y7 + y4*y7);  // w[6]
    flux_J7 = k18*y12*y4*y7/(k31*k32 + k31*y4 + k32*y7 + y4*y7);  // w[7]
    flux_J8 = k18*y12*y4*y7/(k31*k32 + k31*y4 + k32*y7 + y4*y7);  // w[8]
    flux_J10 = y4*(k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // w[10]
    flux_J12 = y6*(k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // w[12]
    flux_J14 = k21*y13*y3*y4/(k36*k37 + k36*y4 + k37*y3 + y3*y4);  // w[14]
    flux_J15 = k21*y13*y3*y4/(k36*k37 + k36*y4 + k37*y3 + y3*y4);  // w[15]
    flux_J16 = k21*y13*y3*y4/(k36*k37 + k36*y4 + k37*y3 + y3*y4);  // w[16]
    flux_J17 = k21*y13*y3*y4/(k36*k37 + k36*y4 + k37*y3 + y3*y4);  // w[17]
    flux_J18 = y3*(k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // w[18]
    flux_J20 = y8*(k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // w[20]
    flux_J23 = y12*(k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // w[23]
    flux_J26 = y9*(k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // w[26]
    flux_J27 = k23*y0*y1*y16/(k40*k42 + k40*y0 + k42*y1 + y0*y1);  // w[27]
    flux_J28 = k23*y0*y1*y16/(k40*k42 + k40*y0 + k42*y1 + y0*y1);  // w[28]
    flux_J29 = k23*y0*y1*y16/(k40*k42 + k40*y0 + k42*y1 + y0*y1);  // w[29]
    flux_J30 = k23*y0*y1*y16/(k40*k42 + k40*y0 + k42*y1 + y0*y1);  // w[30]
    flux_J31 = k29*y5;  // w[31]
    flux_J32 = k29*y5;  // w[32]
    flux_J33 = y1*(k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // w[33]
    flux_J34 = k27*y1*y14*y9*std::pow(1 + y2/k30, -k17)/(k46*k48 + k46*y9 + k48*y1 + y1*y9);  // w[34]
    flux_J35 = k27*y1*y14*y9*std::pow(1 + y2/k30, -k17)/(k46*k48 + k46*y9 + k48*y1 + y1*y9);  // w[35]
    flux_J36 = k27*y1*y14*y9*std::pow(1 + y2/k30, -k17)/(k46*k48 + k46*y9 + k48*y1 + y1*y9);  // w[36]
    flux_J37 = k27*y1*y14*y9*std::pow(1 + y2/k30, -k17)/(k46*k48 + k46*y9 + k48*y1 + y1*y9);  // w[37]
    flux_J39 = y14*(k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // w[39]
    flux_J40 = y5*(k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // w[40]
    flux_J43 = y2*(k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // w[43]
    flux_J44 = y16*(k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // w[44]
    flux_J45 = k22*y16*y2*y3/(k39*k41 + k39*y3 + k41*y2 + y2*y3);  // w[45]
    flux_J46 = k22*y16*y2*y3/(k39*k41 + k39*y3 + k41*y2 + y2*y3);  // w[46]
    flux_J47 = k22*y16*y2*y3/(k39*k41 + k39*y3 + k41*y2 + y2*y3);  // w[47]
    flux_J48 = k22*y16*y2*y3/(k39*k41 + k39*y3 + k41*y2 + y2*y3);  // w[48]
    flux_J49 = k19*y12*y6*y8/(k33*k34 + k33*y8 + k34*y6 + y6*y8);  // w[49]
    flux_J50 = k19*y12*y6*y8/(k33*k34 + k33*y8 + k34*y6 + y6*y8);  // w[50]
    flux_J51 = k19*y12*y6*y8/(k33*k34 + k33*y8 + k34*y6 + y6*y8);  // w[51]
    flux_J52 = k19*y12*y6*y8/(k33*k34 + k33*y8 + k34*y6 + y6*y8);  // w[52]
    flux_J54 = y7*(k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // w[54]
    flux_J55 = y10*(k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // w[55]
    flux_J56 = y11*(k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // w[56]
    flux_J57 = y0*(k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // w[57]
    flux_J61 = y13*(k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // w[61]
    flux_J62 = k28*y7;  // w[62]
    flux_J63 = k28*y7;  // w[63]
    flux_J65 = k43*y15*y9/(k43 + y9);  // w[65]
    flux_J66 = k43*y15*y9/(k43 + y9);  // w[66]
    flux_J67 = k44*y15*y8/(k44 + y8);  // w[67]
    flux_J68 = k44*y15*y8/(k44 + y8);  // w[68]
    flux_J69 = y15*(k49 + k50 + k51 + k52 + k53 + k54 + k55 + k56 + k57 + k58 + k59 + k60 + k61 + k62 + k63 + k64 + k65)/k66;  // w[69]
    flux_J70 = k20*y13*y5*y6/(k35*k38 + k35*y6 + k38*y5 + y5*y6);  // w[70]
    flux_J71 = k20*y13*y5*y6/(k35*k38 + k35*y6 + k38*y5 + y5*y6);  // w[71]
    flux_J72 = k20*y13*y5*y6/(k35*k38 + k35*y6 + k38*y5 + y5*y6);  // w[72]
    flux_J73 = k20*y13*y5*y6/(k35*k38 + k35*y6 + k38*y5 + y5*y6);  // w[73]
}

} // namespace model_PPP_GH_ALLOSTERICS_ADP_NN
} // namespace amici
